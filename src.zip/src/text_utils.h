#pragma once

#include "common.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "data_win.h"
#include "runner.h"
#include "utils.h"

// ===[ Text Utility Functions ]===
// Platform-agnostic text measurement and processing helpers.
// Used by both the renderer (for drawing text) and the VM (for string_width/string_height).

static inline uint16_t TextUtils_latinFallbackCodepoint(uint16_t ch) {
    switch (ch) {
        case 0x00C0: case 0x00C1: case 0x00C2: case 0x00C3:
        case 0x00C4: case 0x00C5: return 'A';
        case 0x00E0: case 0x00E1: case 0x00E2: case 0x00E3:
        case 0x00E4: case 0x00E5: return 'a';
        case 0x00C8: case 0x00C9: case 0x00CA: case 0x00CB: return 'E';
        case 0x00E8: case 0x00E9: case 0x00EA: case 0x00EB: return 'e';
        case 0x00CC: case 0x00CD: case 0x00CE: case 0x00CF: return 'I';
        case 0x00EC: case 0x00ED: case 0x00EE: case 0x00EF: return 'i';
        case 0x00D2: case 0x00D3: case 0x00D4: case 0x00D5:
        case 0x00D6: case 0x00D8: return 'O';
        case 0x00F2: case 0x00F3: case 0x00F4: case 0x00F5:
        case 0x00F6: case 0x00F8: return 'o';
        case 0x00D9: case 0x00DA: case 0x00DB: case 0x00DC: return 'U';
        case 0x00F9: case 0x00FA: case 0x00FB: case 0x00FC: return 'u';
        case 0x00D1: return 'N';
        case 0x00F1: return 'n';
        case 0x00C7: return 'C';
        case 0x00E7: return 'c';
        case 0x00DD: case 0x0178: return 'Y';
        case 0x00FD: case 0x00FF: return 'y';
        case 0x00BF: return '?';
        case 0x00A1: return '!';
        case 0x00AB: case 0x00BB: case 0x201C: case 0x201D: return '"';
        case 0x2018: case 0x2019: case 0x00B4: return '\'';
        case 0x2013: case 0x2014: return '-';
        case 0x2026: return '.';
        case 0x00AA: return 'a';
        case 0x00BA: return 'o';
        default: return ch;
    }
}

static inline uint16_t TextUtils_latinAccentCodepoint(uint16_t ch) {
    switch (ch) {
        case 0x00C1: case 0x00E1: case 0x00C9: case 0x00E9:
        case 0x00CD: case 0x00ED: case 0x00D3: case 0x00F3:
        case 0x00DA: case 0x00FA: case 0x00DD: case 0x00FD: return '\'';
        case 0x00C0: case 0x00E0: case 0x00C8: case 0x00E8:
        case 0x00CC: case 0x00EC: case 0x00D2: case 0x00F2:
        case 0x00D9: case 0x00F9: return '`';
        case 0x00C2: case 0x00E2: case 0x00CA: case 0x00EA:
        case 0x00CE: case 0x00EE: case 0x00D4: case 0x00F4:
        case 0x00DB: case 0x00FB: return '^';
        case 0x00C3: case 0x00E3: case 0x00D5: case 0x00F5:
        case 0x00D1: case 0x00F1: return '~';
        case 0x00C4: case 0x00E4: case 0x00CB: case 0x00EB:
        case 0x00CF: case 0x00EF: case 0x00D6: case 0x00F6:
        case 0x00DC: case 0x00FC: case 0x0178: case 0x00FF: return '"';
        case 0x00C7: case 0x00E7: return ',';
        default: return 0;
    }
}

static inline FontGlyph* TextUtils_findExactGlyph(Font* font, uint16_t ch) {
    // Fast path: ASCII codepoints go through a direct LUT, skipping the linear scan.
    if (128 > ch) return font->glyphLUT[ch];
    repeat(font->glyphCount, i) {
        if (font->glyphs[i].character == ch) return &font->glyphs[i];
    }
    return nullptr;
}

static inline FontGlyph* TextUtils_findGlyph(Font* font, uint16_t ch) {
    FontGlyph* glyph = TextUtils_findExactGlyph(font, ch);
    if (glyph != nullptr) return glyph;

    uint16_t fallback = TextUtils_latinFallbackCodepoint(ch);
    if (fallback != ch) {
        return TextUtils_findExactGlyph(font, fallback);
    }
    return nullptr;
}

static inline float TextUtils_getKerningOffset(FontGlyph* glyph, uint16_t nextCh) {
    repeat(glyph->kerningCount, k) {
        if (glyph->kerning[k].character == (int16_t) nextCh) {
            return glyph->kerning[k].shiftModifier;
        }
    }
    return 0;
}

// Decodes a single UTF-8 codepoint from str at *pos, advances *pos past the consumed bytes.
// Returns the codepoint as uint16_t (sufficient for BMP glyphs). Returns 0xFFFD for invalid sequences.
static inline uint16_t TextUtils_decodeUtf8(const char* str, int32_t len, int32_t* pos) {
    uint8_t b = (uint8_t) str[*pos];
    if (128 > b) {
        // ASCII (0xxxxxxx)
        (*pos)++;
        return b;
    } else if ((b & 0xE0) == 0xC0) {
        // 2-byte sequence (110xxxxx 10xxxxxx)
        if (len > *pos + 1 && ((uint8_t) str[*pos + 1] & 0xC0) == 0x80) {
            uint16_t cp = ((b & 0x1F) << 6) | ((uint8_t) str[*pos + 1] & 0x3F);
            *pos += 2;
            return cp;
        }
    } else if ((b & 0xF0) == 0xE0) {
        // 3-byte sequence (1110xxxx 10xxxxxx 10xxxxxx)
        if (len > *pos + 2 && ((uint8_t) str[*pos + 1] & 0xC0) == 0x80 && ((uint8_t) str[*pos + 2] & 0xC0) == 0x80) {
            uint16_t cp = ((b & 0x0F) << 12) | (((uint8_t) str[*pos + 1] & 0x3F) << 6) | ((uint8_t) str[*pos + 2] & 0x3F);
            *pos += 3;
            return cp;
        }
    } else if ((b & 0xF8) == 0xF0) {
        // 4-byte sequence (11110xxx 10xxxxxx 10xxxxxx 10xxxxxx) - truncated to uint16_t
        if (len > *pos + 3 && ((uint8_t) str[*pos + 1] & 0xC0) == 0x80 && ((uint8_t) str[*pos + 2] & 0xC0) == 0x80 && ((uint8_t) str[*pos + 3] & 0xC0) == 0x80) {
            *pos += 4;
            return 0xFFFD; // Beyond BMP, return replacement character
        }
    }
    // Invalid or truncated sequence
    (*pos)++;
    return 0xFFFD;
}

static inline int32_t TextUtils_utf8AdvanceCodepoints(const char* str, int32_t byteLen, int32_t codepointsToSkip) {
    int32_t pos = 0;
    while (pos < byteLen && codepointsToSkip > 0) {
        pos++;
        while (pos < byteLen && ((uint8_t)str[pos] & 0xC0) == 0x80) {
            pos++;
        }
        codepointsToSkip--;
    }
    return pos;
}

static inline int32_t TextUtils_utf8CodepointCount(const char* str, int32_t byteLen) {
    int32_t count = 0;
    for (int32_t i = 0; i < byteLen; i++) {
        if (((uint8_t)str[i] & 0xC0) != 0x80) {
            count++;
        }
    }
    return count;
}

static inline int32_t TextUtils_utf8EncodeCodepoint(uint32_t cp, char* out) {
    if (cp <= 0x7FU) {
        out[0] = (char) cp;
        return 1;
    }
    if (cp <= 0x7FFU) {
        out[0] = (char) (0xC0U | (cp >> 6));
        out[1] = (char) (0x80U | (cp & 0x3FU));
        return 2;
    }
    if (cp <= 0xFFFFU) {
        out[0] = (char) (0xE0U | (cp >> 12));
        out[1] = (char) (0x80U | ((cp >> 6) & 0x3FU));
        out[2] = (char) (0x80U | (cp & 0x3FU));
        return 3;
    }
    if (cp <= 0x10FFFFU) {
        out[0] = (char) (0xF0U | (cp >> 18));
        out[1] = (char) (0x80U | ((cp >> 12) & 0x3FU));
        out[2] = (char) (0x80U | ((cp >> 6) & 0x3FU));
        out[3] = (char) (0x80U | (cp & 0x3FU));
        return 4;
    }
    return 0;
}

// Line stride used for multi-line text. Matches HTML5 runner behavior:
// - When `linesep` is not provided to draw_text, it defaults to `font.TextHeight('M')`
//   which is `max_glyph_height * scaleY`. We apply scaleY via the transform matrix already,
//   so we return the raw max glyph height here.
// - Falls back to emSize only if the font has no glyphs recorded.
static inline float TextUtils_lineStride(Font* font) {
    if (font->maxGlyphHeight > 0) return (float) font->maxGlyphHeight;
    return font->emSize;
}

static inline float TextUtils_measureLineWidth(Font* font, const char* line, int32_t len) {
    float width = 0;
    int32_t pos = 0;
    uint16_t ch = 0;
    bool hasCh = false;
    if (len > pos) {
        ch = TextUtils_decodeUtf8(line, len, &pos);
        hasCh = true;
    }

    while (hasCh) {
        FontGlyph* glyph = TextUtils_findGlyph(font, ch);

        // Decode the next codepoint once - reused for kerning AND as next iteration's ch
        uint16_t nextCh = 0;
        bool hasNext = len > pos;
        if (hasNext) nextCh = TextUtils_decodeUtf8(line, len, &pos);

        if (glyph != nullptr) {
            width += glyph->shift;
            if (hasNext) width += TextUtils_getKerningOffset(glyph, nextCh);
        }

        ch = nextCh;
        hasCh = hasNext;
    }
    return width;
}

// Result of GML text preprocessing. If owning is true, the caller must free the text pointer.
typedef struct {
    const char* text;
    bool owning;
} PreprocessedText;

// Frees the text pointer if it is owning.
static inline void PreprocessedText_free(PreprocessedText pt) {
    if (pt.owning) free((char*) pt.text);
}

// Preprocesses GML text: converts unescaped # to \n, and \# to literal #.
// Uses a fused single-pass approach: scans for # and only allocates if one is found.
static inline PreprocessedText TextUtils_preprocessGmlText(const char* text) {
    int32_t len = (int32_t) strlen(text);

    // Scan until we find a #
    for (int32_t i = 0; len > i; i++) {
        if (text[i] == '#') {
            // Found one - allocate and process from here
            char* result = safeMalloc(len + 1);
            memcpy(result, text, i);
            int32_t out = i;

            // Check if the # is escaped (\#)
            if (out > 0 && result[out - 1] == '\\') {
                result[out - 1] = '#';
            } else {
                result[out++] = '\n';
            }

            // Process the rest of the string
            for (int32_t j = i + 1; len > j; j++) {
                if (text[j] == '#') {
                    if (out > 0 && result[out - 1] == '\\') {
                        result[out - 1] = '#';
                    } else {
                        result[out++] = '\n';
                    }
                } else {
                    result[out++] = text[j];
                }
            }
            result[out] = '\0';
            return (PreprocessedText){ .text = result, .owning = true };
        }
    }

    // No # found, return original pointer without allocating
    return (PreprocessedText){ .text = text, .owning = false };
}

// Preprocess GML text ONLY if the runner is not GameMaker: Studio 2
static inline PreprocessedText TextUtils_preprocessGmlTextIfNeeded(Runner* runner, const char* text) {
    if (DataWin_isVersionAtLeast(runner->dataWin, 2, 0, 0, 0))
        return (PreprocessedText){ .text = text, .owning = false };
    return TextUtils_preprocessGmlText(text);
}

// Returns true if c is \r or \n
static inline bool TextUtils_isNewlineChar(char c) {
    return c == '\n' || c == '\r';
}

// Returns true if c is ' ' or \t
static inline bool TextUtils_isWhitespaceChar(char c) {
    return c == ' ' || c == '\t';
}

// Counts the number of lines in preprocessed text, treating \r\n and \n\r as single breaks
static inline int32_t TextUtils_countLines(const char* text, int32_t len) {
    int32_t count = 1;
    for (int32_t i = 0; len > i; i++) {
        if (TextUtils_isNewlineChar(text[i])) {
            count++;
            // Treat \r\n or \n\r as a single line break
            if (len > i + 1 && TextUtils_isNewlineChar(text[i + 1]) && text[i] != text[i + 1]) {
                i++;
            }
        }
    }
    return count;
}

// Advances lineStart past the newline at lineEnd, treating \r\n and \n\r as single breaks
static inline int32_t TextUtils_skipNewline(const char* text, int32_t lineEnd, int32_t textLen) {
    int32_t next = lineEnd + 1;
    if (textLen > next && TextUtils_isNewlineChar(text[next]) && text[lineEnd] != text[next]) {
        next++;
    }
    return next;
}

static char* TextUtils_trimTrailingWhitespace(char* str) {
    size_t len = strlen(str);
    while (len > 0 && (TextUtils_isWhitespaceChar(str[len - 1]) || TextUtils_isNewlineChar(str[len - 1]))) {
        len--;
    }
    str[len] = '\0';
    return str;
}
