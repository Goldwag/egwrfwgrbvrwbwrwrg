#include "runner.h"
#include "data_win.h"
#include "instance.h"
#include "native_scripts.h"
#include "renderer.h"
#include "vm.h"
#include "utils.h"
#include "json_writer.h"
#include "collision.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "debug_overlay.h"
#include "stb_ds.h"

#ifndef CTR_OPT_DIAGNOSTICS
#define CTR_OPT_DIAGNOSTICS 0
#endif

// ===[ Runtime Layer Teardown Helpers ]===
void Runner_freeRuntimeLayer(RuntimeLayer* runtimeLayer) {
    if (runtimeLayer->dynamicName != nullptr) {
        free(runtimeLayer->dynamicName);
        runtimeLayer->dynamicName = nullptr;
    }
    size_t elementCount = arrlenu(runtimeLayer->elements);
    repeat(elementCount, i) {
        RuntimeLayerElement* el = &runtimeLayer->elements[i];
        if (el->backgroundElement != nullptr) {
            free(el->backgroundElement);
            el->backgroundElement = nullptr;
        }
        if (el->spriteElement != nullptr) {
            free(el->spriteElement);
            el->spriteElement = nullptr;
        }
    }
    arrfree(runtimeLayer->elements);
    runtimeLayer->elements = nullptr;
}

static void freeRuntimeLayersArray(RuntimeLayer** runtimeLayerArray) {
    size_t count = arrlenu(*runtimeLayerArray);
    repeat(count, i) {
        Runner_freeRuntimeLayer(&(*runtimeLayerArray)[i]);
    }
    arrfree(*runtimeLayerArray);
    *runtimeLayerArray = nullptr;
}

// ===[ Helper: Find event action in object hierarchy ]===
// Resolves the handler for (objectIndex, eventType, eventSubtype) via the precomputed ResolvedEventTable.
// Returns the CODE chunk handler id, or -1 if the object does not respond.
// If outOwnerObjectIndex is non-null, it is set to the resolved owner objectIndex (-1 if not found).
static int32_t findEventCodeIdAndOwner(Runner* runner, int32_t objectIndex, int32_t eventType, int32_t eventSubtype, int32_t* outOwnerObjectIndex) {
    int32_t slot = EventSlotMap_lookup(&runner->eventSlotMap, eventType, eventSubtype);
    if (0 > slot) {
        if (outOwnerObjectIndex != nullptr) *outOwnerObjectIndex = -1;
        return -1;
    }
    return ResolvedEventTable_lookup(&runner->eventTable, objectIndex, slot, outOwnerObjectIndex);
}

// ===[ Per-Object Instance Lists ]===
// Each instance lives in the list of its own object and every ancestor object (descendant-inclusive).
// This mirrors the native runner and lets collision dispatch iterate only the candidate instances for a target object, instead of scanning the whole room per collision event.
// The difference is that the native runner uses a linked list, while we move things manually with memmove.

void Runner_addInstanceToObjectLists(Runner* runner, Instance* inst) {
    DataWin* dataWin = runner->dataWin;
    int32_t currentObj = inst->objectIndex;
    int32_t depth = 0;
    while (currentObj >= 0 && dataWin->objt.count > (uint32_t) currentObj && 32 > depth) {
        arrput(runner->instancesByObject[currentObj], inst);
        currentObj = dataWin->objt.objects[currentObj].parentId;
        depth++;
    }
    if (inst->objectIndex >= 0 && dataWin->objt.count > (uint32_t) inst->objectIndex) {
        arrput(runner->instancesByExactObject[inst->objectIndex], inst);
    }
    SpatialGrid_markInstanceAsDirty(runner->spatialGrid, inst);
}

// Stable remove of inst from list, preserving creation order. Returns true if removed.
static bool removeInstanceFromList(Instance*** listPtr, Instance* inst) {
    Instance** list = *listPtr;
    int32_t n = (int32_t) arrlen(list);
    repeat(n, i) {
        if (list[i] == inst) {
            if (n - 1 > i) memmove(&list[i], &list[i + 1], (size_t) (n - 1 - i) * sizeof(Instance*));
            arrsetlen(*listPtr, n - 1);
            return true;
        }
    }
    return false;
}

void Runner_removeInstanceFromObjectLists(Runner* runner, Instance* inst) {
    DataWin* dataWin = runner->dataWin;
    int32_t currentObj = inst->objectIndex;
    int32_t depth = 0;
    while (currentObj >= 0 && dataWin->objt.count > (uint32_t) currentObj && 32 > depth) {
        removeInstanceFromList(&runner->instancesByObject[currentObj], inst);
        currentObj = dataWin->objt.objects[currentObj].parentId;
        depth++;
    }
    if (inst->objectIndex >= 0 && dataWin->objt.count > (uint32_t) inst->objectIndex) {
        removeInstanceFromList(&runner->instancesByExactObject[inst->objectIndex], inst);
    }
    SpatialGrid_markInstanceAsDirty(runner->spatialGrid, inst);
}

void Runner_clearAllObjectLists(Runner* runner) {
    if (runner->instancesByObject == nullptr) return;
    uint32_t count = runner->dataWin->objt.count;
    repeat(count, i) {
        arrsetlen(runner->instancesByObject[i], 0);
        if (runner->instancesByExactObject != nullptr) {
            arrsetlen(runner->instancesByExactObject[i], 0);
        }
    }
}

int32_t Runner_pushInstancesOfObject(Runner* runner, int32_t targetObjIndex) {
    int32_t base = (int32_t) arrlen(runner->instanceSnapshots);

    if (0 > targetObjIndex || (uint32_t) targetObjIndex >= runner->dataWin->objt.count)
        return base;

    Instance** source = runner->instancesByObject[targetObjIndex];
    int32_t sourceCount = (int32_t) arrlen(source);

    if (0 >= sourceCount)
        return base;

    arrsetlen(runner->instanceSnapshots, base + sourceCount);
    memcpy(&runner->instanceSnapshots[base], source, (size_t) sourceCount * sizeof(Instance*));
    return base;
}

void Runner_popInstanceSnapshot(Runner* runner, int32_t base) {
    arrsetlen(runner->instanceSnapshots, base);
}

int32_t Runner_pushInstancesForTarget(Runner* runner, int32_t target) {
    int32_t base = (int32_t) arrlen(runner->instanceSnapshots);
    if (target >= 0 && 100000 > target) {
        return Runner_pushInstancesOfObject(runner, target);
    }
    if (target == INSTANCE_ALL) {
        int32_t total = (int32_t) arrlen(runner->instances);
        if (0 >= total)
            return base;
        arrsetlen(runner->instanceSnapshots, base + total);
        memcpy(&runner->instanceSnapshots[base], runner->instances, (size_t) total * sizeof(Instance*));
        return base;
    }
    if (target >= 100000) {
        Instance* inst = hmget(runner->instancesById, target);
        if (inst != nullptr) arrput(runner->instanceSnapshots, inst);
        return base;
    }
    return base;
}

// ===[ Event Execution ]===

static void setVMInstanceContext(VMContext* vm, Instance* instance) {
    vm->currentInstance = instance;
}

static void restoreVMInstanceContext(VMContext* vm, Instance* savedInstance) {
    vm->currentInstance = savedInstance;
}

static void executeCode(Runner* runner, Instance* instance, int32_t codeId) {
    // GameMaker does use codeIds less than 0, we'll just pretend we didn't hear them...
    if (0 > codeId) return;

    VMContext* vm = runner->vmContext;

    // Save instance context
    Instance* savedInstance = (Instance*) vm->currentInstance;

    // Save full VM execution state, because VM_executeCode overwrites all of these.
    // This is necessary for nested execution (e.g., instance_create triggering a Create
    // event while another event's executeLoop is still on the call stack).
    uint8_t* savedBytecodeBase = vm->bytecodeBase;
    uint32_t savedIP = vm->ip;
    uint32_t savedCodeEnd = vm->codeEnd;
    const char* savedCodeName = vm->currentCodeName;
    RValue* savedLocalVars = vm->localVars;
    uint32_t savedLocalVarCount = vm->localVarCount;
    IntIntHashMap* savedCodeLocalsSlotMap = vm->currentCodeLocalsSlotMap;
    int32_t savedCodeIndex = vm->currentCodeIndex;
    int32_t savedStackTop = vm->stack.top;

    // Save stack values (VM_executeCode resets stack.top to 0, which would let
    // the nested execution overwrite the caller's stack slot values)
    RValue* savedStackValues = nullptr;
    if (savedStackTop > 0) {
        savedStackValues = safeMalloc((uint32_t) savedStackTop * sizeof(RValue));
        memcpy(savedStackValues, vm->stack.slots, (uint32_t) savedStackTop * sizeof(RValue));
    }

    // Set instance context
    setVMInstanceContext(vm, instance);

    const char* codeName = runner->dataWin->code.entries[codeId].name;
    NativeCodeFunc nativeFunc = NativeScripts_find(codeName);
    if (nativeFunc != nullptr) {
        nativeFunc(vm, runner, instance);
    } else {
        RValue result = VM_executeCode(vm, codeId);
        RValue_free(&result);
    }

    // Restore instance context
    restoreVMInstanceContext(vm, savedInstance);

    // Restore VM execution state
    vm->bytecodeBase = savedBytecodeBase;
    vm->ip = savedIP;
    vm->codeEnd = savedCodeEnd;
    vm->currentCodeName = savedCodeName;
    vm->localVars = savedLocalVars;
    vm->localVarCount = savedLocalVarCount;
    vm->currentCodeLocalsSlotMap = savedCodeLocalsSlotMap;
    vm->currentCodeIndex = savedCodeIndex;
    vm->stack.top = savedStackTop;

    // Restore stack values
    if (savedStackTop > 0) {
        memcpy(vm->stack.slots, savedStackValues, (uint32_t) savedStackTop * sizeof(RValue));
        free(savedStackValues);
    }
}

const char* Runner_getEventName(int32_t eventType, int32_t eventSubtype) {
    switch (eventType) {
        case EVENT_CREATE:  return "Create";
        case EVENT_DESTROY: return "Destroy";
        case EVENT_ALARM:   return "Alarm";
        case EVENT_COLLISION: return "Collision";
        case EVENT_STEP:
            switch (eventSubtype) {
                case STEP_BEGIN:  return "BeginStep";
                case STEP_NORMAL: return "NormalStep";
                case STEP_END:    return "EndStep";
                default:          return "Step";
            }
        case EVENT_DRAW:
            switch (eventSubtype) {
                case DRAW_NORMAL:    return "Draw";
                case DRAW_GUI:       return "DrawGUI";
                case DRAW_BEGIN:     return "DrawBegin";
                case DRAW_END:       return "DrawEnd";
                case DRAW_GUI_BEGIN: return "DrawGUIBegin";
                case DRAW_GUI_END:   return "DrawGUIEnd";
                case DRAW_PRE:       return "DrawPre";
                case DRAW_POST:      return "DrawPost";
                default:             return "Draw";
            }
        case EVENT_KEYBOARD:   return "Keyboard";
        case EVENT_OTHER:
            switch (eventSubtype) {
                case OTHER_OUTSIDE_ROOM:    return "OutsideRoom";
                case OTHER_GAME_START:      return "GameStart";
                case OTHER_ROOM_START:      return "RoomStart";
                case OTHER_ROOM_END:        return "RoomEnd";
                case OTHER_END_OF_PATH:     return "EndOfPath";
                case OTHER_USER0 +  0:      return "UserEvent0";
                case OTHER_USER0 +  1:      return "UserEvent1";
                case OTHER_USER0 +  2:      return "UserEvent2";
                case OTHER_USER0 +  3:      return "UserEvent3";
                case OTHER_USER0 +  4:      return "UserEvent4";
                case OTHER_USER0 +  5:      return "UserEvent5";
                case OTHER_USER0 +  6:      return "UserEvent6";
                case OTHER_USER0 +  7:      return "UserEvent7";
                case OTHER_USER0 +  8:      return "UserEvent8";
                case OTHER_USER0 +  9:      return "UserEvent9";
                case OTHER_USER0 + 10:      return "UserEvent10";
                case OTHER_USER0 + 11:      return "UserEvent11";
                case OTHER_USER0 + 12:      return "UserEvent12";
                case OTHER_USER0 + 13:      return "UserEvent13";
                case OTHER_USER0 + 14:      return "UserEvent14";
                case OTHER_USER0 + 15:      return "UserEvent15";
                default:                    return "Other";
            }
        case EVENT_KEYPRESS:   return "KeyPress";
        case EVENT_KEYRELEASE: return "KeyRelease";
        case EVENT_PRECREATE:  return "PreCreate";
        default: return "Unknown";
    }
}

// Executes an already-resolved event handler (see findEventCodeIdAndOwner) and verified codeId >= 0.
static void Runner_executeResolvedEvent(Runner* runner, Instance* instance, int32_t eventType, int32_t eventSubtype, int32_t codeId, int32_t ownerObjectIndex) {
    VMContext* vm = runner->vmContext;
    int32_t savedEventType = vm->currentEventType;
    int32_t savedEventSubtype = vm->currentEventSubtype;
    int32_t savedEventObjectIndex = vm->currentEventObjectIndex;

    vm->currentEventType = eventType;
    vm->currentEventSubtype = eventSubtype;
    vm->currentEventObjectIndex = ownerObjectIndex;

#ifdef ENABLE_VM_TRACING
    if (codeId >= 0 && shlen(vm->eventsToBeTraced) != -1) {
        const char* eventName = Runner_getEventName(eventType, eventSubtype);
        const char* objectName = runner->dataWin->objt.objects[instance->objectIndex].name;

        bool shouldTrace = shgeti(vm->eventsToBeTraced, "*") != -1 || shgeti(vm->eventsToBeTraced, eventName) != -1 || shgeti(vm->eventsToBeTraced, objectName) != -1;

        if (shouldTrace) {
            if (eventType == EVENT_ALARM) {
                fprintf(stderr, "Runner: [%s] %s %d (instanceId=%d)\n", objectName, eventName, eventSubtype, instance->instanceId);
            } else {
                fprintf(stderr, "Runner: [%s] %s (instanceId=%d)\n", objectName, eventName, instance->instanceId);
            }
        }
    }
#endif

    executeCode(runner, instance, codeId);

    vm->currentEventType = savedEventType;
    vm->currentEventSubtype = savedEventSubtype;
    vm->currentEventObjectIndex = savedEventObjectIndex;
}

void Runner_executeEventFromObject(Runner* runner, Instance* instance, int32_t startObjectIndex, int32_t eventType, int32_t eventSubtype) {
    int32_t ownerObjectIndex = -1;
    int32_t codeId = findEventCodeIdAndOwner(runner, startObjectIndex, eventType, eventSubtype, &ownerObjectIndex);
    // Fast path: If the codeId is invalid, let's bail out fast
    // This way can avoid the need of loading and saving the current state variables
    if (0 > codeId)
        return;
    Runner_executeResolvedEvent(runner, instance, eventType, eventSubtype, codeId, ownerObjectIndex);
}

void Runner_executeEvent(Runner* runner, Instance* instance, int32_t eventType, int32_t eventSubtype) {
    Runner_executeEventFromObject(runner, instance, instance->objectIndex, eventType, eventSubtype);
}

// Events that GMS 2.3+ routes through the per-object obj_has_event table instead of Perform_Event_All.
// Anything else (BC16 ALWAYS; BC17 non-perObject) goes through Runner_executeEventForAll
static bool eventUsesBC17PerObjectDispatch(int32_t eventType) {
    return eventType == EVENT_STEP || eventType == EVENT_ALARM || eventType == EVENT_KEYBOARD || eventType == EVENT_KEYPRESS || eventType == EVENT_KEYRELEASE;
}

void Runner_executeEventForAll(Runner* runner, int32_t eventType, int32_t eventSubtype) {
    int32_t slot = EventSlotMap_lookup(&runner->eventSlotMap, eventType, eventSubtype);
    if (slot == -1) return;

    // We always snapshot the iteration list before dispatching so instances spawned during this phase do NOT fire the current event.
    Instance** scratch = runner->eventDispatchInstances;
    arrsetlen(scratch, 0);

    // On GMS 2.x, the native runner dispatches events in the eventUsesPerObjectDispatch set per-object. Route those through executeEventPerObject to match.
    if (DataWin_isVersionAtLeast(runner->dataWin, 2, 0, 0, 0) && eventUsesBC17PerObjectDispatch(eventType)) {
        ResolvedEventTable* table = &runner->eventTable;
        uint32_t entryCount;
        SlotResponderEntry* entries = ResolvedEventTable_slotEntries(table, slot, &entryCount);
        if (entryCount == 0) return;

        repeat(entryCount, i) {
            int32_t concreteObj = entries[i].concreteObjectId;
            Instance** bucket = runner->instancesByExactObject[concreteObj];
            int32_t bucketCount = (int32_t) arrlen(bucket);
            if (bucketCount == 0) continue;
            size_t base = arrlenu(scratch);
            arrsetlen(scratch, base + (size_t) bucketCount);
            memcpy(&scratch[base], bucket, (size_t) bucketCount * sizeof(Instance*));
        }
        runner->eventDispatchInstances = scratch; // arrsetlen may have realloced

        int32_t snapshotCount = (int32_t) arrlen(scratch);
        repeat(snapshotCount, i) {
            Instance* inst = scratch[i];
            if (!inst->active) continue;
            Runner_executeEvent(runner, inst, eventType, eventSubtype);
        }
        return;
    }

    int32_t count = (int32_t) arrlen(runner->instances);
    if (count == 0) return;
    arrsetlen(scratch, count);
    memcpy(scratch, runner->instances, (size_t) count * sizeof(Instance*));
    runner->eventDispatchInstances = scratch;

    repeat(count, i) {
        Instance* inst = scratch[i];
        if (!inst->active) continue;
        // Skip non-responders without entering Runner_executeEvent. ResolvedEventTable_lookup is a tiny CSR scan; non-responders bail in a few compares and avoid the VM state save/restore overhead inside Runner_executeEventFromObject.
        int32_t ownerObjectIndex = -1;
        int32_t codeId = ResolvedEventTable_lookup(&runner->eventTable, inst->objectIndex, slot, &ownerObjectIndex);
        if (0 > codeId) continue;
        Runner_executeResolvedEvent(runner, inst, eventType, eventSubtype, codeId, ownerObjectIndex);
    }
}

// ===[ Background Scrolling & Drawing ]===

void Runner_scrollBackgrounds(Runner* runner) {
    repeat(8, i) {
        RuntimeBackground* bg = &runner->backgrounds[i];
        if (!bg->visible) continue;
        bg->x += bg->speedX;
        bg->y += bg->speedY;
    }
}

void Runner_drawBackgrounds(Runner* runner, bool foreground) {
    if (runner->renderer == nullptr) return;
    DataWin* dataWin = runner->dataWin;
    float roomW = (float) runner->currentRoom->width;
    float roomH = (float) runner->currentRoom->height;

    repeat(8, i) {
        RuntimeBackground* bg = &runner->backgrounds[i];
        if (!bg->visible || bg->foreground != foreground) continue;
        if (0 > bg->backgroundIndex) continue;

        int32_t tpagIndex = Renderer_resolveBackgroundTPAGIndex(dataWin, bg->backgroundIndex);
        // Bound check on BOTH ends: < 0 is the "unresolved" sentinel from
        // resolveAllTPAGReferences, but a stale/garbage value can still pass
        // it while being out of range — e.g. when a mod has BGND entries
        // pointing at TPAG offsets that no longer exist after a vanilla
        // -> mod merge. Citra catches this as `unmapped Read16 @ 0x12`
        // (boundingHeight at +18 in TexturePageItem); on real hardware it
        // would be a hard data abort. Skip cleanly instead.
        if (0 > tpagIndex || (uint32_t) tpagIndex >= dataWin->tpag.count) continue;
        if (dataWin->tpag.items == nullptr) continue;

        if (bg->stretch) {
            // Stretch to fill room dimensions
            TexturePageItem* tpag = &dataWin->tpag.items[tpagIndex];
            if (tpag->boundingWidth == 0 || tpag->boundingHeight == 0) continue;
            float xscale = roomW / (float) tpag->boundingWidth;
            float yscale = roomH / (float) tpag->boundingHeight;
            runner->renderer->vtable->drawSprite(runner->renderer, tpagIndex, 0.0f, 0.0f, 0.0f, 0.0f, xscale, yscale, 0.0f, 0xFFFFFF, bg->alpha);
        } else if (bg->tileX || bg->tileY) {
            Renderer_drawBackgroundTiled(runner->renderer, tpagIndex, bg->x, bg->y, bg->tileX, bg->tileY, roomW, roomH, bg->alpha);
        } else {
            // Single placement
            runner->renderer->vtable->drawSprite(runner->renderer, tpagIndex, bg->x, bg->y, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0xFFFFFF, bg->alpha);
        }
    }
}

// ===[ Draw ]===

static int compareDrawableDepth(const void* a, const void* b) {
    const Drawable* da = (const Drawable*) a;
    const Drawable* db = (const Drawable*) b;
    // Higher depth draws first (behind), lower depth draws last (in front)
    if (da->depth > db->depth) return -1;
    if (db->depth > da->depth) return 1;
    // At same depth, tiles before instances (tiles are background)
    if (da->type < db->type) return -1;
    if (db->type < da->type) return 1;
    // At same depth and type, preserve original room order (higher index draws later = in front)
    if (da->type == DRAWABLE_TILE) {
        if (db->tileIndex > da->tileIndex) return -1;
        if (da->tileIndex > db->tileIndex) return 1;
    }
    // At same depth, newer instances (higher instanceId) draw FIRST (behind), older draw LAST (front).
    if (da->type == DRAWABLE_INSTANCE && db->type == DRAWABLE_INSTANCE) {
        if (db->instance->instanceId > da->instance->instanceId) return 1;
        if (da->instance->instanceId > db->instance->instanceId) return -1;
    }
    // At same depth, layers with higher ID draw first (behind).
    if (da->type == DRAWABLE_LAYER && db->type == DRAWABLE_LAYER) {
        if (db->runtimeLayerId > da->runtimeLayerId) return 1;
        if (da->runtimeLayerId > db->runtimeLayerId) return -1;
    }
    return 0;
}

static void fireDrawSubtype(Runner* runner, Drawable* drawables, int32_t drawableCount, int32_t subtype) {
    int32_t slot = EventSlotMap_lookup(&runner->eventSlotMap, EVENT_DRAW, subtype);
    if (slot == -1) return;

    repeat(drawableCount, i) {
        Drawable* d = &drawables[i];
        if (d->type != DRAWABLE_INSTANCE)
            continue;

        Instance* inst = d->instance;
        if (!inst->active || !inst->visible)
            continue;

        int32_t ownerObjectIndex = -1;
        int32_t codeId = ResolvedEventTable_lookup(&runner->eventTable, inst->objectIndex, slot, &ownerObjectIndex);
        if (0 > codeId) continue;
        Runner_executeResolvedEvent(runner, inst, EVENT_DRAW, subtype, codeId, ownerObjectIndex);
    }
}

static void Runner_getCurrentViewBounds(Runner* runner, float* left, float* top, float* right, float* bottom) {
    float l = 0.0f;
    float t = 0.0f;
    float r = runner && runner->currentRoom ? (float) runner->currentRoom->width : 0.0f;
    float b = runner && runner->currentRoom ? (float) runner->currentRoom->height : 0.0f;

    if (runner != nullptr && runner->viewsEnabled &&
        runner->viewCurrent >= 0 && runner->viewCurrent < MAX_VIEWS) {
        RuntimeView* view = &runner->views[runner->viewCurrent];
        if (view->enabled) {
            GMLCamera* camera = Runner_getCameraForView(runner, runner->viewCurrent);
            int32_t viewX = camera != nullptr ? camera->viewX : view->viewX;
            int32_t viewY = camera != nullptr ? camera->viewY : view->viewY;
            int32_t viewW = camera != nullptr ? camera->viewWidth : view->viewWidth;
            int32_t viewH = camera != nullptr ? camera->viewHeight : view->viewHeight;
            if (viewW > 0 && viewH > 0) {
                l = (float) viewX;
                t = (float) viewY;
                r = (float) (viewX + viewW);
                b = (float) (viewY + viewH);
            }
        }
    }

    *left = l;
    *top = t;
    *right = r;
    *bottom = b;
}

// GMS2 tilemap cell bit layout (matches HTML5 Function_Layers.js TileIndex/Mirror/Flip/Rotate masks)
#define GMS2_TILE_INDEX_MASK  0x0007FFFF // bits 0..18
#define GMS2_TILE_MIRROR_MASK 0x10000000 // bit 28 (horizontal flip)
#define GMS2_TILE_FLIP_MASK   0x20000000 // bit 29 (vertical flip)
#define GMS2_TILE_ROTATE_MASK 0x40000000 // bit 30 (90 CW)

static void Runner_prepareAutomaticTileLayerDraw(Runner* runner) {
    if (runner == nullptr || runner->renderer == nullptr) return;
    if (runner->gameProfile != GAME_PROFILE_DELTARUNE) return;

    RendererVtable* vtable = runner->renderer->vtable;
    if (vtable == nullptr) return;

    // Parsed room tile layers are engine-owned background geometry. Deltarune's
    // Draw events use surfaces/masks heavily, so do not let those GPU states
    // leak into the automatic tile pass.
    if (vtable->gpuSetColorWriteEnable != nullptr)
        vtable->gpuSetColorWriteEnable(runner->renderer, true, true, true, true);
    if (vtable->gpuSetAlphaTestEnable != nullptr)
        vtable->gpuSetAlphaTestEnable(runner->renderer, false);
    if (vtable->gpuSetBlendEnable != nullptr)
        vtable->gpuSetBlendEnable(runner->renderer, true);
    if (vtable->gpuSetBlendMode != nullptr)
        vtable->gpuSetBlendMode(runner->renderer, bm_normal);
}

void Runner_drawTileLayerEx(Runner* runner, RoomLayerTilesData* data, float layerOffsetX, float layerOffsetY, float alpha) {
    if (data == nullptr || data->tileData == nullptr) return;
    if (0 > data->backgroundIndex) return;
    if (alpha <= 0.0f) return;

    DataWin* dw = runner->dataWin;
    if ((uint32_t) data->backgroundIndex >= dw->bgnd.count) return;

    Background* tileset = &dw->bgnd.backgrounds[data->backgroundIndex];
    if (tileset->gms2TileWidth == 0 || tileset->gms2TileHeight == 0 || tileset->gms2TileColumns == 0) return;

    int32_t tpagIndex = tileset->tpagIndex;
    if (0 > tpagIndex) return;
    if ((uint32_t) tpagIndex >= dw->tpag.count || dw->tpag.items == nullptr) return;
    TexturePageItem* tpag = &dw->tpag.items[tpagIndex];

    uint32_t tileW = tileset->gms2TileWidth;
    uint32_t tileH = tileset->gms2TileHeight;
    uint32_t borderX = tileset->gms2OutputBorderX;
    uint32_t borderY = tileset->gms2OutputBorderY;
    uint32_t columns = tileset->gms2TileColumns;
    if (alpha > 1.0f) alpha = 1.0f;
    uint8_t alphaByte = (uint8_t) (alpha * 255.0f + 0.5f);

    int32_t startX = 0;
    int32_t startY = 0;
    int32_t endX = (int32_t) data->tilesX;
    int32_t endY = (int32_t) data->tilesY;
    if (runner->gameProfile != GAME_PROFILE_DELTARUNE) {
        float viewLeft, viewTop, viewRight, viewBottom;
        Runner_getCurrentViewBounds(runner, &viewLeft, &viewTop, &viewRight, &viewBottom);
        startX = (int32_t) floorf((viewLeft - layerOffsetX) / (float) tileW) - 1;
        startY = (int32_t) floorf((viewTop - layerOffsetY) / (float) tileH) - 1;
        endX = (int32_t) ceilf((viewRight - layerOffsetX) / (float) tileW) + 1;
        endY = (int32_t) ceilf((viewBottom - layerOffsetY) / (float) tileH) + 1;
        if (startX < 0) startX = 0;
        if (startY < 0) startY = 0;
        if (endX > (int32_t) data->tilesX) endX = (int32_t) data->tilesX;
        if (endY > (int32_t) data->tilesY) endY = (int32_t) data->tilesY;
    }
    if (startX >= endX || startY >= endY) return;

    static bool rotateWarned = false;

    for (int32_t ty = startY; ty < endY; ty++) {
        for (int32_t tx = startX; tx < endX; tx++) {
            uint32_t cell = data->tileData[ty * data->tilesX + tx];
            uint32_t tileIndex = cell & GMS2_TILE_INDEX_MASK;
            if (tileIndex == 0) continue; // 0 = empty

            bool mirror = (cell & GMS2_TILE_MIRROR_MASK) != 0;
            bool flip = (cell & GMS2_TILE_FLIP_MASK) != 0;
            bool rotate = (cell & GMS2_TILE_ROTATE_MASK) != 0;

            if (rotate && !rotateWarned) {
                fprintf(stderr, "Runner: WARNING: GMS2 tile layer has rotated tiles; rotation not yet implemented, drawing unrotated\n");
                rotateWarned = true;
            }

            float xscale = mirror ? -1.0f : 1.0f;
            float yscale = flip ? -1.0f : 1.0f;

            // With negative scale the quad grows in the opposite direction, so shift the
            // destination by one tile to keep the origin at the top-left of the cell.
            int32_t dstX = (int32_t) (tx * tileW) + (mirror ? (int32_t) tileW : 0);
            int32_t dstY = (int32_t) (ty * tileH) + (flip ? (int32_t) tileH : 0);

            // GMS2 room tile data stores the tileset slot directly. Slot 0 is
            // reserved for the empty tile and is already skipped above, so do
            // not subtract one here. This matches UndertaleModTool's room
            // renderer and avoids shifting Deltarune tilesets into repeated
            // or visually blank slots.
            uint32_t tileSlot = tileIndex;
            uint32_t col = tileSlot % columns;
            uint32_t row = tileSlot / columns;

            int32_t srcX = (int32_t) (col * (tileW + 2 * borderX) + borderX);
            int32_t srcY = (int32_t) (row * (tileH + 2 * borderY) + borderY);
            int32_t srcW = (int32_t) tileW;
            int32_t srcH = (int32_t) tileH;
            float drawX = (float) dstX + layerOffsetX;
            float drawY = (float) dstY + layerOffsetY;

            // GMS2 tilemaps already know the exact BGND TPAG. Drawing the part
            // directly avoids the platform-specific RoomTile path and keeps
            // large Deltarune tile layers on the same renderer path as sprites.
            if (tpag->targetX > srcX) {
                int32_t clip = tpag->targetX - srcX;
                drawX += (float) clip * xscale;
                srcW -= clip;
                srcX = tpag->targetX;
            }
            if (tpag->targetY > srcY) {
                int32_t clip = tpag->targetY - srcY;
                drawY += (float) clip * yscale;
                srcH -= clip;
                srcY = tpag->targetY;
            }

            int32_t contentRight = tpag->targetX + tpag->sourceWidth;
            int32_t contentBottom = tpag->targetY + tpag->sourceHeight;
            if (srcX + srcW > contentRight) srcW = contentRight - srcX;
            if (srcY + srcH > contentBottom) srcH = contentBottom - srcY;
            if (srcW <= 0 || srcH <= 0) continue;

            runner->renderer->vtable->drawSpritePart(
                runner->renderer, tpagIndex,
                srcX - tpag->targetX, srcY - tpag->targetY,
                srcW, srcH,
                drawX, drawY, xscale, yscale,
                0.0f, 0.0f, 0.0f,
                0xFFFFFFu, (float) alphaByte / 255.0f);
        }
    }
}

void Runner_drawTileLayer(Runner* runner, RoomLayerTilesData* data, float layerOffsetX, float layerOffsetY) {
    Runner_drawTileLayerEx(runner, data, layerOffsetX, layerOffsetY, 1.0f);
}

// Returns true if "drawables" is already in compareDrawableDepth order. Used by the sort-dirty path to skip qsort when small depth perturbations didn't actually cross any neighbor.
static bool isDrawableArraySorted(Drawable* drawables, int32_t count) {
    for (int32_t i = 1; count > i; i++) {
        if (compareDrawableDepth(&drawables[i - 1], &drawables[i]) > 0) return false;
    }
    return true;
}

// Refreshes each entry's cached .depth from the live instance/runtime-layer pointer. Tile entries never change depth mid-room so they're left alone.
static void refreshDrawableDepths(Runner* runner, Drawable* drawables, int32_t count) {
    for (int32_t i = 0; count > i; i++) {
        Drawable* d = &drawables[i];
        if (d->type == DRAWABLE_INSTANCE) {
            d->depth = d->instance->depth;
        } else if (d->type == DRAWABLE_LAYER) {
            RuntimeLayer* rl = Runner_findRuntimeLayerById(runner, d->runtimeLayerId);
            if (rl != nullptr) d->depth = rl->depth;
        }
    }
}

// Rebuilds runner->cachedDrawables when invalidated. Two-tier strategy:
//   structureDirty - the SET of entries changed (instance/layer create or destroy, room change). Drop the cache and re-add every instance/tile/runtime-layer, then qsort.
//   sortDirty only - the entries are the same but .depth values may have shifted. Refresh depths from the live sources and only qsort if the order actually broke.
static void rebuildDrawableCacheIfDirty(Runner* runner) {
    if (runner->drawableListStructureDirty) {
        arrsetlen(runner->cachedDrawables, 0);
        Room* room = runner->currentRoom;
        if (room == nullptr) {
            runner->drawableListStructureDirty = false;
            runner->drawableListSortDirty = false;
            return;
        }

        int32_t instanceCount = (int32_t) arrlen(runner->instances);
        repeat(instanceCount, i) {
            Instance* inst = runner->instances[i];
            Drawable d = { .type = DRAWABLE_INSTANCE, .depth = inst->depth, .instance = inst };
            arrput(runner->cachedDrawables, d);
        }

        if (!DataWin_isVersionAtLeast(runner->dataWin, 2, 0, 0, 0)) {
            repeat(room->tileCount, i) {
                RoomTile* tile = &room->tiles[i];
                Drawable d = { .type = DRAWABLE_TILE, .depth = tile->tileDepth, .tileIndex = (int32_t) i };
                arrput(runner->cachedDrawables, d);
            }
        } else {
            size_t runtimeLayersCount = arrlenu(runner->runtimeLayers);
            repeat(runtimeLayersCount, i) {
                RuntimeLayer* runtimeLayer = &runner->runtimeLayers[i];
                Drawable d = { .type = DRAWABLE_LAYER, .depth = runtimeLayer->depth, .runtimeLayerId = (int32_t) runtimeLayer->id };
                arrput(runner->cachedDrawables, d);
            }
        }

        int32_t count = (int32_t) arrlen(runner->cachedDrawables);
        if (count > 1) {
            qsort(runner->cachedDrawables, count, sizeof(Drawable), compareDrawableDepth);
        }
        runner->drawableListStructureDirty = false;
        runner->drawableListSortDirty = false;
        return;
    }

    if (runner->drawableListSortDirty) {
        int32_t count = (int32_t) arrlen(runner->cachedDrawables);
        refreshDrawableDepths(runner, runner->cachedDrawables, count);
        if (count > 1 && !isDrawableArraySorted(runner->cachedDrawables, count)) {
            qsort(runner->cachedDrawables, count, sizeof(Drawable), compareDrawableDepth);
        }
        runner->drawableListSortDirty = false;
    }
}

void Runner_draw(Runner* runner) {
    Room* room = runner->currentRoom;

    // native_scripts.c writes directly to inst->depth (e.g. y-sort: inst->depth = 50000 - inst->y*10)
    // bypassing VMBuiltins_setVariable, which is the only code path that flips drawableListSortDirty.
    // Force a depth refresh every frame so the cache reflects the live values; isDrawableArraySorted
    // is O(N) and skips qsort when nothing actually crossed a neighbour.
    runner->drawableListSortDirty = true;
    rebuildDrawableCacheIfDirty(runner);
    int32_t drawableCount = (int32_t) arrlen(runner->cachedDrawables);
    Drawable* drawables = runner->cachedDrawables;

    // Draw non-foreground backgrounds (behind everything)
    if (!DataWin_isVersionAtLeast(runner->dataWin, 2, 0, 0, 0))
        Runner_drawBackgrounds(runner, false);

    // Fire draw subtypes in correct GameMaker order. fireDrawSubtype walks the cache and filters inline.
    fireDrawSubtype(runner, drawables, drawableCount, DRAW_PRE);
    fireDrawSubtype(runner, drawables, drawableCount, DRAW_BEGIN);

    // Draw interleaved tiles and instances
    repeat(drawableCount, i) {
        Drawable* d = &drawables[i];
        if (d->type == DRAWABLE_TILE) {
            if (runner->renderer != nullptr) {
                RoomTile* tile = &room->tiles[d->tileIndex];
                // Skip tiles whose layer was hidden via tile_layer_hide(). Filtered here (not in the cache) so toggling layer visibility doesn't invalidate.
                ptrdiff_t layerIdx = hmgeti(runner->tileLayerMap, tile->tileDepth);
                if (layerIdx >= 0 && !runner->tileLayerMap[layerIdx].value.visible) continue;
                float offsetX = 0.0f, offsetY = 0.0f;
                if (layerIdx >= 0) {
                    offsetX = runner->tileLayerMap[layerIdx].value.offsetX;
                    offsetY = runner->tileLayerMap[layerIdx].value.offsetY;
                }

#ifdef ENABLE_VM_TRACING
                // Trace tile drawing if requested
                if (shlen(runner->vmContext->tilesToBeTraced) > 0) {
                    DataWin* dataWin = runner->dataWin;
                    const char* bgName = (tile->backgroundDefinition >= 0 && dataWin->bgnd.count > (uint32_t) tile->backgroundDefinition) ? dataWin->bgnd.backgrounds[tile->backgroundDefinition].name : "<none>";
                    const char* roomName = room->name;

                    bool shouldTrace = shgeti(runner->vmContext->tilesToBeTraced, "*") != -1 || shgeti(runner->vmContext->tilesToBeTraced, bgName) != -1 || shgeti(runner->vmContext->tilesToBeTraced, roomName) != -1;

                    if (shouldTrace) {
                        int32_t tpagIndex = Renderer_resolveObjectTPAGIndex(dataWin, tile);
                        if (tpagIndex >= 0) {
                            TexturePageItem* tpag = &dataWin->tpag.items[tpagIndex];
                            fprintf(stderr, "Runner: [%s] Drawing tile #%d bg=%s(%d) tpag(srcX=%d srcY=%d srcW=%d srcH=%d tgtX=%d tgtY=%d bndW=%d bndH=%d page=%d) tile(srcX=%d srcY=%d w=%u h=%u) at pos=(%d,%d) depth=%d\n", roomName, d->tileIndex, bgName, tile->backgroundDefinition, tpag->sourceX, tpag->sourceY, tpag->sourceWidth, tpag->sourceHeight, tpag->targetX, tpag->targetY, tpag->boundingWidth, tpag->boundingHeight, tpag->texturePageId, tile->sourceX, tile->sourceY, tile->width, tile->height, tile->x, tile->y, tile->tileDepth);

                            // Warn if tile source rect exceeds TPAG content bounds
                            if ((uint32_t) (tile->sourceX + tile->width) > (uint32_t) tpag->sourceWidth || (uint32_t) (tile->sourceY + tile->height) > (uint32_t) tpag->sourceHeight) {
                                fprintf(stderr, "Runner: [%s] WARNING: Tile #%d source rect (%d,%d %ux%u) exceeds TPAG content bounds (%dx%d)\n", roomName, d->tileIndex, tile->sourceX, tile->sourceY, tile->width, tile->height, tpag->sourceWidth, tpag->sourceHeight);
                            }
                        } else {
                            fprintf(stderr, "Runner: [%s] Drawing tile #%d bg=%s(%d) tpag=UNRESOLVED tile(srcX=%d srcY=%d w=%u h=%u) at pos=(%d,%d) depth=%d\n", roomName, d->tileIndex, bgName, tile->backgroundDefinition, tile->sourceX, tile->sourceY, tile->width, tile->height, tile->x, tile->y, tile->tileDepth);
                        }
                    }
                }
#endif

                Renderer_drawTile(runner->renderer, tile, offsetX, offsetY);
            }
        } else if (d->type == DRAWABLE_INSTANCE) {
            Instance* inst = d->instance;
            // Filter inactive/invisible instances at draw time so the cache doesn't need invalidation when those flags toggle.
            if (!inst->active || !inst->visible) continue;
            int32_t ownerObjectIndex = -1;
            int32_t codeId = findEventCodeIdAndOwner(runner, inst->objectIndex, EVENT_DRAW, DRAW_NORMAL, &ownerObjectIndex);
            if (codeId >= 0) {
                Runner_executeResolvedEvent(runner, inst, EVENT_DRAW, DRAW_NORMAL, codeId, ownerObjectIndex);
            } else if (runner->renderer != nullptr) {
                Renderer_drawSelf(runner->renderer, inst);
            }
        } else if (d->type == DRAWABLE_LAYER)
        {
            RuntimeLayer* runtimeLayer = Runner_findRuntimeLayerById(runner, d->runtimeLayerId);
            if (runtimeLayer == nullptr || !runtimeLayer->visible) continue;
            float layerOffsetX = runtimeLayer->xOffset;
            float layerOffsetY = runtimeLayer->yOffset;

            // Dynamic layers created via layer_create have no parsed RoomLayer, render their runtime elements instead (backgrounds, in the future sprites/tilemaps).
            if (runtimeLayer->dynamic) {
                if (runner->renderer == nullptr) continue;

                DataWin* dataWin = runner->dataWin;
                float roomW = (float) runner->currentRoom->width;
                float roomH = (float) runner->currentRoom->height;

                size_t elementCount = arrlenu(runtimeLayer->elements);
                repeat(elementCount, j) {
                    RuntimeLayerElement* layerElement = &runtimeLayer->elements[j];
                    if (layerElement->type == RuntimeLayerElementType_Background && layerElement->backgroundElement != nullptr) {
                        RuntimeBackgroundElement* bg = layerElement->backgroundElement;
                        if (!layerElement->visible || !bg->visible) continue;
                        float alpha = bg->alpha * layerElement->alpha;
                        if (alpha <= 0.0f) continue;
                        if (bg->spriteIndex < 0) {
                            runner->renderer->vtable->drawRectangle(
                                runner->renderer,
                                0.0f, 0.0f, roomW, roomH,
                                bg->blend, alpha, false);
                            continue;
                        }
                        int32_t tpagIndex = Renderer_resolveTPAGIndex(dataWin, bg->spriteIndex, (int32_t) bg->frameIndex);
                        // See note in the legacy backgrounds path above — the
                        // resolved TPAG index can pass `< 0` while still being
                        // out-of-range or pointing at a NULL items table when
                        // the data.win's TPAG chunk is empty / desynced.
                        if (0 > tpagIndex || (uint32_t) tpagIndex >= dataWin->tpag.count) continue;
                        if (dataWin->tpag.items == nullptr) continue;
                        if (bg->stretch) {
                            TexturePageItem* tpag = &dataWin->tpag.items[tpagIndex];
                            if (tpag->boundingWidth == 0 || tpag->boundingHeight == 0) continue;
                            float xscale = roomW / (float) tpag->boundingWidth;
                            float yscale = roomH / (float) tpag->boundingHeight;
                            runner->renderer->vtable->drawSprite(runner->renderer, tpagIndex, 0.0f, 0.0f, 0.0f, 0.0f, xscale, yscale, 0.0f, bg->blend, alpha);
                        } else if (bg->htiled || bg->vtiled) {
                            Renderer_drawBackgroundTiled(runner->renderer, tpagIndex, layerOffsetX + bg->xOffset, layerOffsetY + bg->yOffset, bg->htiled, bg->vtiled, roomW, roomH, alpha);
                        } else {
                            Renderer_drawSpriteExt(runner->renderer, bg->spriteIndex, (int32_t) bg->frameIndex,
                                                   layerOffsetX + bg->xOffset, layerOffsetY + bg->yOffset,
                                                   bg->xScale, bg->yScale, 0.0f, bg->blend, alpha);
                        }
                    }
                }
                continue;
            }

            // Parsed layer: look up the RoomLayer by ID and render its data-driven content.
            RoomLayer* parsedLayer = Runner_findRoomLayerById(runner, (int32_t) runtimeLayer->id);
            if (parsedLayer == nullptr) continue;
            if (parsedLayer->type == RoomLayerType_Assets) {
                RoomLayerAssetsData* data = parsedLayer->assetsData;
                size_t tileElementCount = arrlenu(runtimeLayer->elements);
                repeat(data->legacyTileCount, j) {
                    if (runner->renderer != nullptr) {
                        RoomTile* tile = &data->legacyTiles[j];
                        RuntimeLayerElement* tileEl = nullptr;
                        if (runner->gameProfile == GAME_PROFILE_DELTARUNE) {
                            repeat(tileElementCount, k) {
                                RuntimeLayerElement* candidate = &runtimeLayer->elements[k];
                                if (candidate->type == RuntimeLayerElementType_Tile && candidate->tileElement == tile) {
                                    tileEl = candidate;
                                    break;
                                }
                            }
                        }
                        if (tileEl != nullptr && !tileEl->visible) continue;
                        if (tileEl != nullptr && tileEl->alpha <= 0.0f) continue;
                        // Check if this tile's layer is hidden via tile_layer_hide()
                        ptrdiff_t layerIdx = hmgeti(runner->tileLayerMap, tile->tileDepth);
                        if (layerIdx >= 0 && !runner->tileLayerMap[layerIdx].value.visible) continue;
                        float offsetX = 0.0f, offsetY = 0.0f;
                        if (layerIdx >= 0) {
                            offsetX = runner->tileLayerMap[layerIdx].value.offsetX;
                            offsetY = runner->tileLayerMap[layerIdx].value.offsetY;
                        }

#ifdef ENABLE_VM_TRACING
                        // Trace tile drawing if requested
                        if (shlen(runner->vmContext->tilesToBeTraced) > 0) {
                            DataWin* dataWin = runner->dataWin;
                            const char* bgName = (tile->backgroundDefinition >= 0 && dataWin->bgnd.count > (uint32_t) tile->backgroundDefinition) ? dataWin->bgnd.backgrounds[tile->backgroundDefinition].name : "<none>";
                            const char* roomName = room->name;

                            bool shouldTrace = shgeti(runner->vmContext->tilesToBeTraced, "*") != -1 || shgeti(runner->vmContext->tilesToBeTraced, bgName) != -1 || shgeti(runner->vmContext->tilesToBeTraced, roomName) != -1;

                            if (shouldTrace) {
                                int32_t tpagIndex = Renderer_resolveObjectTPAGIndex(dataWin, tile);
                                if (tpagIndex >= 0) {
                                    TexturePageItem* tpag = &dataWin->tpag.items[tpagIndex];
                                    fprintf(stderr, "Runner: [%s] Drawing tile #%d bg=%s(%d) tpag(srcX=%d srcY=%d srcW=%d srcH=%d tgtX=%d tgtY=%d bndW=%d bndH=%d page=%d) tile(srcX=%d srcY=%d w=%u h=%u) at pos=(%d,%d) depth=%d\n", roomName, d->tileIndex, bgName, tile->backgroundDefinition, tpag->sourceX, tpag->sourceY, tpag->sourceWidth, tpag->sourceHeight, tpag->targetX, tpag->targetY, tpag->boundingWidth, tpag->boundingHeight, tpag->texturePageId, tile->sourceX, tile->sourceY, tile->width, tile->height, tile->x, tile->y, tile->tileDepth);

                                    // Warn if tile source rect exceeds TPAG content bounds
                                    if ((uint32_t) (tile->sourceX + tile->width) > (uint32_t) tpag->sourceWidth || (uint32_t) (tile->sourceY + tile->height) > (uint32_t) tpag->sourceHeight) {
                                        fprintf(stderr, "Runner: [%s] WARNING: Tile #%d source rect (%d,%d %ux%u) exceeds TPAG content bounds (%dx%d)\n", roomName, d->tileIndex, tile->sourceX, tile->sourceY, tile->width, tile->height, tpag->sourceWidth, tpag->sourceHeight);
                                    }
                                } else {
                                    fprintf(stderr, "Runner: [%s] Drawing tile #%d bg=%s(%d) tpag=UNRESOLVED tile(srcX=%d srcY=%d w=%u h=%u) at pos=(%d,%d) depth=%d\n", roomName, d->tileIndex, bgName, tile->backgroundDefinition, tile->sourceX, tile->sourceY, tile->width, tile->height, tile->x, tile->y, tile->tileDepth);
                                }
                            }
                        }
#endif

                        if (tileEl != nullptr && tileEl->alpha < 0.999f) {
                            RoomTile alphaTile = *tile;
                            uint8_t baseAlphaByte = (uint8_t) ((alphaTile.color >> 24) & 0xFF);
                            float baseAlpha = baseAlphaByte == 0 ? 1.0f : (float) baseAlphaByte / 255.0f;
                            float combinedAlpha = baseAlpha * tileEl->alpha;
                            if (combinedAlpha < 0.0f) combinedAlpha = 0.0f;
                            if (combinedAlpha > 1.0f) combinedAlpha = 1.0f;
                            uint8_t outAlpha = (uint8_t) (combinedAlpha * 255.0f + 0.5f);
                            alphaTile.color = (alphaTile.color & 0x00FFFFFFu) | ((uint32_t) outAlpha << 24);
                            Renderer_drawTile(runner->renderer, &alphaTile, offsetX, offsetY);
                        } else {
                            Renderer_drawTile(runner->renderer, tile, offsetX, offsetY);
                        }
                    }
                }

                // Sprite elements are rendered from the runtime element list (not the parsed data) so that layer_sprite_destroy can remove them at runtime.
                size_t elementCount = arrlenu(runtimeLayer->elements);
                repeat(elementCount, j) {
                    if (runner->renderer == nullptr) break;
                    RuntimeLayerElement* el = &runtimeLayer->elements[j];
                    if (el->type != RuntimeLayerElementType_Sprite || el->spriteElement == nullptr) continue;
                    RuntimeSpriteElement* spr = el->spriteElement;
                    if (0 > spr->spriteIndex) continue;
                    Renderer_drawSpriteExt(
                        runner->renderer, spr->spriteIndex, (int32_t) spr->frameIndex,
                        spr->x + layerOffsetX, spr->y + layerOffsetY, spr->scaleX,
                        spr->scaleY, spr->rotation, spr->color,
                        1.0);
                }
            } else if(parsedLayer->type == RoomLayerType_Background) {
                if (runner->renderer == nullptr) return;
                DataWin* dataWin = runner->dataWin;
                float roomW = (float) runner->currentRoom->width;
                float roomH = (float) runner->currentRoom->height;
                RoomLayerBackgroundData* data = parsedLayer->backgroundData;

                RuntimeBackgroundElement* bg = nullptr;
                float elementAlpha = 1.0f;
                size_t elementCount = arrlenu(runtimeLayer->elements);
                repeat(elementCount, j) {
                    RuntimeLayerElement* el = &runtimeLayer->elements[j];
                    if (el->type == RuntimeLayerElementType_Background && el->backgroundElement != nullptr) {
                        if (!el->visible) continue;
                        bg = el->backgroundElement;
                        elementAlpha = el->alpha;
                        break;
                    }
                }

                int32_t spriteIndex = bg != nullptr ? bg->spriteIndex : data->spriteIndex;
                bool visible = bg != nullptr ? bg->visible : data->visible;
                bool stretch = bg != nullptr ? bg->stretch : data->stretch;
                bool hTiled = bg != nullptr ? bg->htiled : data->hTiled;
                bool vTiled = bg != nullptr ? bg->vtiled : data->vTiled;
                float xScale = bg != nullptr ? bg->xScale : 1.0f;
                float yScale = bg != nullptr ? bg->yScale : 1.0f;
                uint32_t blend = bg != nullptr ? bg->blend : (data->color & 0x00FFFFFFu);
                float alpha = (bg != nullptr ? bg->alpha : (float) ((data->color >> 24) & 0xFF) / 255.0f) * elementAlpha;
                float xOffset = bg != nullptr ? bg->xOffset : 0.0f;
                float yOffset = bg != nullptr ? bg->yOffset : 0.0f;
                int32_t frameIndex = bg != nullptr ? (int32_t) bg->frameIndex : (int32_t) data->firstFrame;
                if (!visible || alpha <= 0.0f) continue;

                if (spriteIndex < 0) {
                    runner->renderer->vtable->drawRectangle(
                        runner->renderer,
                        0.0f, 0.0f, roomW, roomH,
                        blend, alpha, false);
                    continue;
                }

                int32_t tpagIndex = Renderer_resolveTPAGIndex(dataWin, spriteIndex, frameIndex);
                // See note in the legacy backgrounds path above.
                if (0 > tpagIndex || (uint32_t) tpagIndex >= dataWin->tpag.count) continue;
                if (dataWin->tpag.items == nullptr) continue;

                if (stretch) {
                    TexturePageItem* tpag = &dataWin->tpag.items[tpagIndex];
                    if (tpag->boundingWidth == 0 || tpag->boundingHeight == 0) continue;
                    float xscale = roomW / (float) tpag->boundingWidth;
                    float yscale = roomH / (float) tpag->boundingHeight;
                    runner->renderer->vtable->drawSprite(runner->renderer, tpagIndex, 0.0f, 0.0f, 0.0f, 0.0f, xscale, yscale, 0.0f, blend, alpha);
                } else if (hTiled || vTiled) {
                    Renderer_drawBackgroundTiled(runner->renderer, tpagIndex, layerOffsetX + xOffset, layerOffsetY + yOffset, hTiled, vTiled, roomW, roomH, alpha);
                } else {
                    Renderer_drawSpriteExt(runner->renderer, spriteIndex, frameIndex,
                                           layerOffsetX + xOffset, layerOffsetY + yOffset,
                                           xScale, yScale, 0.0f, blend, alpha);
                }
            } else if(parsedLayer->type == RoomLayerType_Instances) {
                // Instance depth is assigned from layers during room init (initRoom).
                // Nothing to do here - instances are drawn from the DRAWABLE_INSTANCE path.
            } else if(parsedLayer->type == RoomLayerType_Tiles) {
                if (runner->renderer == nullptr) continue;
                RuntimeLayerElement* tilemapEl = nullptr;
                size_t elementCount = arrlenu(runtimeLayer->elements);
                repeat(elementCount, j) {
                    RuntimeLayerElement* el = &runtimeLayer->elements[j];
                    if (el->type == RuntimeLayerElementType_Tilemap &&
                        el->tilemapElement == parsedLayer->tilesData) {
                        tilemapEl = el;
                        break;
                    }
                }
                if (tilemapEl != nullptr) {
                    if (!tilemapEl->visible || tilemapEl->alpha <= 0.0f) continue;
                    Runner_prepareAutomaticTileLayerDraw(runner);
                    Runner_drawTileLayerEx(runner, parsedLayer->tilesData, layerOffsetX, layerOffsetY, tilemapEl->alpha);
                } else {
                    Runner_prepareAutomaticTileLayerDraw(runner);
                    Runner_drawTileLayer(runner, parsedLayer->tilesData, layerOffsetX, layerOffsetY);
                }
            }
        }
    }

    fireDrawSubtype(runner, drawables, drawableCount, DRAW_END);

    // Draw foreground backgrounds (in front of instances, behind GUI)
    Runner_drawBackgrounds(runner, true);

    fireDrawSubtype(runner, drawables, drawableCount, DRAW_POST);
}

void Runner_drawGUI(Runner* runner) {
    rebuildDrawableCacheIfDirty(runner);
    Drawable* drawables = runner->cachedDrawables;
    int32_t drawableCount = (int32_t) arrlen(drawables);

    fireDrawSubtype(runner, drawables, drawableCount, DRAW_GUI_BEGIN);
    fireDrawSubtype(runner, drawables, drawableCount, DRAW_GUI);
    fireDrawSubtype(runner, drawables, drawableCount, DRAW_GUI_END);
}

void Runner_computeViewDisplayScale(Runner* runner, int32_t gameW, int32_t gameH, float* outScaleX, float* outScaleY) {
    *outScaleX = 1.0f;
    *outScaleY = 1.0f;
    
    bool viewsEnabled = runner->viewsEnabled;
    if (viewsEnabled) {
        int32_t minLeft = INT32_MAX, minTop = INT32_MAX;
        int32_t maxRight = INT32_MIN, maxBottom = INT32_MIN;
        repeat(MAX_VIEWS, vi) {
            RuntimeView* view = &runner->views[vi];
            if (!view->enabled) continue;
            if (minLeft > view->portX) minLeft = view->portX;
            if (minTop > view->portY) minTop = view->portY;
            int32_t right = view->portX + view->portWidth;
            int32_t bottom = view->portY + view->portHeight;
            if (right > maxRight) maxRight = right;
            if (bottom > maxBottom) maxBottom = bottom;
        }
        if (maxRight > minLeft && maxBottom > minTop) {
            *outScaleX = (float) gameW / (float) (maxRight - minLeft);
            *outScaleY = (float) gameH / (float) (maxBottom - minTop);
        }
    }
}

void Runner_drawViews(Runner* runner, int32_t gameW, int32_t gameH, float displayScaleX, float displayScaleY, bool debugShowCollisionMasks) {
    Renderer* renderer = runner->renderer;
    bool anyViewRendered = false;

    bool viewsEnabled = runner->viewsEnabled;

    if (viewsEnabled) {
        repeat(MAX_VIEWS, vi) {
            RuntimeView* view = &runner->views[vi];
            if (!view->enabled) continue;
            GMLCamera* camera = Runner_getCameraForView(runner, (int32_t) vi);

            int32_t viewX = camera != nullptr ? camera->viewX : view->viewX;
            int32_t viewY = camera != nullptr ? camera->viewY : view->viewY;
            int32_t viewW = camera != nullptr ? camera->viewWidth : view->viewWidth;
            int32_t viewH = camera != nullptr ? camera->viewHeight : view->viewHeight;
            int32_t portX = (int32_t) ((float) view->portX * displayScaleX + 0.5f);
            int32_t portY = (int32_t) ((float) view->portY * displayScaleY + 0.5f);
            int32_t portW = (int32_t) ((float) view->portWidth * displayScaleX + 0.5f);
            int32_t portH = (int32_t) ((float) view->portHeight * displayScaleY + 0.5f);
            float viewAngle = camera != nullptr ? camera->viewAngle : view->viewAngle;

            runner->viewCurrent = (int32_t) vi;
            renderer->vtable->beginView(renderer, viewX, viewY, viewW, viewH, portX, portY, portW, portH, viewAngle);

            Runner_draw(runner);

            if (debugShowCollisionMasks) DebugOverlay_drawCollisionMasks(runner);

            renderer->vtable->endView(renderer);

            int32_t guiW = runner->guiWidth > 0 ? runner->guiWidth : portW;
            int32_t guiH = runner->guiHeight > 0 ? runner->guiHeight : portH;
            renderer->vtable->beginGUI(renderer, guiW, guiH, portX, portY, portW, portH);
            Runner_drawGUI(runner);
            renderer->vtable->endGUI(renderer);

            anyViewRendered = true;
        }
    }

    if (!anyViewRendered) {
        // No views enabled: render with default full-screen view
        runner->viewCurrent = 0;
        renderer->vtable->beginView(renderer, 0, 0, gameW, gameH, 0, 0, gameW, gameH, 0.0f);
        Runner_draw(runner);

        if (debugShowCollisionMasks) DebugOverlay_drawCollisionMasks(runner);

        renderer->vtable->endView(renderer);

        int32_t guiW = runner->guiWidth > 0 ? runner->guiWidth : gameW;
        int32_t guiH = runner->guiHeight > 0 ? runner->guiHeight : gameH;
        renderer->vtable->beginGUI(renderer, guiW, guiH, 0, 0, gameW, gameH);
        Runner_drawGUI(runner);
        renderer->vtable->endGUI(renderer);
    }

    // Reset view_current to 0 so non-Draw events (Step, Alarm, Create) see view_current = 0
    runner->viewCurrent = 0;
}

// ===[ Instance Creation Helper ]===

static bool isObjectDisabled(Runner* runner, int32_t objectIndex) {
    if (runner->disabledObjects == nullptr) return false;
    const char* name = runner->dataWin->objt.objects[objectIndex].name;
    return shgeti(runner->disabledObjects, name) != -1;
}

static Instance* createAndInitInstance(Runner* runner, int32_t instanceId, int32_t objectIndex, GMLReal x, GMLReal y) {
    DataWin* dataWin = runner->dataWin;
    require(objectIndex >= 0 && dataWin->objt.count > (uint32_t) objectIndex);

    GameObject* objDef = &dataWin->objt.objects[objectIndex];

    Instance* inst = Instance_create(instanceId, objectIndex, x, y);

    // Copy properties from object definition
    inst->spriteIndex = objDef->spriteId;
    inst->visible = objDef->visible;
    inst->solid = objDef->solid;
    inst->persistent = objDef->persistent;
    inst->depth = objDef->depth;
    inst->maskIndex = objDef->textureMaskId;

    hmput(runner->instancesById, instanceId, inst);
    arrput(runner->instances, inst);
    Runner_addInstanceToObjectLists(runner, inst);
    runner->drawableListStructureDirty = true;

#ifdef ENABLE_VM_TRACING
    if (shgeti(runner->vmContext->instanceLifecyclesToBeTraced, "*") != -1 || shgeti(runner->vmContext->instanceLifecyclesToBeTraced, objDef->name) != -1) {
        fprintf(stderr, "VM: Instance %s (instanceId=%d,objectIndex=%d) created at (%f, %f)\n", objDef->name, instanceId, inst->objectIndex, x, y);
    }
#endif

    return inst;
}

// ===[ Room Management ]===

// Collect persistent instances from the previous room (they travel with the player), and free the rest.
// You should re-append them at the tail AFTER creating the new room's own instances, so the iteration order matches the native runner: room-local instances first, persistent arrivals last.
static Instance** takePersistentInstances(Runner* runner) {
    Instance** carriedPersistent = nullptr;
    int32_t oldCount = (int32_t) arrlen(runner->instances);
    repeat(oldCount, i) {
        Instance* inst = runner->instances[i];
        if (inst->persistent) {
#ifdef ENABLE_VM_TRACING
            GameObject* gameObject = &runner->dataWin->objt.objects[inst->objectIndex];
            if (shgeti(runner->vmContext->instanceLifecyclesToBeTraced, "*") != -1 || shgeti(runner->vmContext->instanceLifecyclesToBeTraced, gameObject->name) != -1) {
                fprintf(stderr, "VM: Instance %s (instanceId=%d,objectIndex=%d) has been persisted at (%f, %f) due to room change\n", gameObject->name, inst->instanceId, inst->objectIndex, inst->x, inst->y);
            }
#endif

            // The spatial grid is recreated per room, so any cell coordinates the instance was tracking belong to the old grid and must not be reused.
            arrsetlen(inst->collisionCells, 0);
            inst->spatialGridDirty = false;

            arrput(carriedPersistent, inst);
        } else {
#ifdef ENABLE_VM_TRACING
            GameObject* gameObject = &runner->dataWin->objt.objects[inst->objectIndex];
            if (shgeti(runner->vmContext->instanceLifecyclesToBeTraced, "*") != -1 || shgeti(runner->vmContext->instanceLifecyclesToBeTraced, gameObject->name) != -1) {
                fprintf(stderr, "VM: Instance %s (instanceId=%d,objectIndex=%d) destroyed at (%f, %f) due to room change\n", gameObject->name, inst->instanceId, inst->objectIndex, inst->x, inst->y);
            }
#endif

            hmdel(runner->instancesById, inst->instanceId);
            Instance_free(inst);
        }
    }

    arrfree(runner->instances);
    runner->instances = nullptr;

    // The per-object lists referenced both the freed non-persistents and the carried persistents; clear them entirely.
    // Persistents are re-added when they return via returnPersistentInstances, and room-local instances are added as they get created.
    Runner_clearAllObjectLists(runner);

    return carriedPersistent;
}

// Append the carried-over persistent instances at the tail of runner->instances and free the temporary array. Pairs with takePersistentInstances.
static void returnPersistentInstances(Runner* runner, Instance** carriedPersistent) {
    repeat(arrlen(carriedPersistent), i) {
        arrput(runner->instances, carriedPersistent[i]);
        Runner_addInstanceToObjectLists(runner, carriedPersistent[i]);
    }
    arrfree(carriedPersistent);
}

static void copyRoomViewToRuntimeView(RoomView* roomView, RuntimeView* runtimeView) {
    runtimeView->enabled = roomView->enabled;
    runtimeView->viewX = roomView->viewX;
    runtimeView->viewY = roomView->viewY;
    runtimeView->viewWidth = roomView->viewWidth;
    runtimeView->viewHeight = roomView->viewHeight;
    runtimeView->portX = roomView->portX;
    runtimeView->portY = roomView->portY;
    runtimeView->portWidth = roomView->portWidth;
    runtimeView->portHeight = roomView->portHeight;
    runtimeView->borderX = roomView->borderX;
    runtimeView->borderY = roomView->borderY;
    runtimeView->speedX = roomView->speedX;
    runtimeView->speedY = roomView->speedY;
    runtimeView->objectId = roomView->objectId;
    runtimeView->viewAngle = 0;
    runtimeView->cameraId = -1;
    runtimeView->surfaceId = -1;
}

static void initDefaultCameraFromRoomView(GMLCamera* camera, RoomView* roomView) {
    camera->allocated = true;
    camera->viewX = roomView->viewX;
    camera->viewY = roomView->viewY;
    camera->viewWidth = roomView->viewWidth;
    camera->viewHeight = roomView->viewHeight;
    camera->borderX = roomView->borderX;
    camera->borderY = roomView->borderY;
    camera->speedX = roomView->speedX;
    camera->speedY = roomView->speedY;
    camera->objectId = roomView->objectId;
    camera->viewAngle = 0;
}

static char asciiLower(char c) {
    return (c >= 'A' && c <= 'Z') ? (char)(c - 'A' + 'a') : c;
}

static bool asciiEndsWithIgnoreCase(const char* text, const char* suffix) {
    if (text == nullptr || suffix == nullptr) return false;
    size_t textLen = strlen(text);
    size_t suffixLen = strlen(suffix);
    if (textLen < suffixLen) return false;
    const char* start = text + textLen - suffixLen;
    for (size_t i = 0; i < suffixLen; i++) {
        if (asciiLower(start[i]) != asciiLower(suffix[i])) return false;
    }
    return true;
}

static bool spriteVarNameLooksLikeSpriteRef(const char* name) {
    if (name == nullptr) return false;
    size_t len = strlen(name);
    if (len == 6 && asciiEndsWithIgnoreCase(name, "sprite")) return true;
    if (strcmp(name, "sprite_index") == 0 || strcmp(name, "spr") == 0 ||
        strcmp(name, "sprites") == 0) {
        return true;
    }
    if (asciiEndsWithIgnoreCase(name, "_sprite") ||
        asciiEndsWithIgnoreCase(name, "Sprite") ||
        asciiEndsWithIgnoreCase(name, "_spr")) {
        return true;
    }
    if (len == 7 && asciiEndsWithIgnoreCase(name, "sprite")) {
        char dir = asciiLower(name[0]);
        return dir == 'd' || dir == 'r' || dir == 'u' || dir == 'l';
    }
    return false;
}

static bool varIdLooksLikeSpriteRef(DataWin* dataWin, int32_t varID) {
    repeat(dataWin->vari.variableCount, i) {
        Variable* var = &dataWin->vari.variables[i];
        if (var->varID == varID && spriteVarNameLooksLikeSpriteRef(var->name)) return true;
    }
    return false;
}

static bool isMaincharaInstance(DataWin* dataWin, Instance* inst) {
    if (inst == nullptr || inst->objectIndex < 0 ||
        (uint32_t)inst->objectIndex >= dataWin->objt.count) {
        return false;
    }
    const char* name = dataWin->objt.objects[inst->objectIndex].name;
    return name != nullptr && strcmp(name, "obj_mainchara") == 0;
}

static bool queueSpriteIndexOnce(DataWin* dataWin, bool* seen, int32_t** spriteQueue,
                                 int32_t spriteIndex) {
    if (spriteIndex < 0 || (uint32_t)spriteIndex >= dataWin->sprt.count) return false;
    if (seen != nullptr && seen[spriteIndex]) return false;

    if (seen != nullptr) seen[spriteIndex] = true;
    arrput(*spriteQueue, spriteIndex);
    return true;
}

static bool queueSpriteNameOnce(DataWin* dataWin, bool* seen, int32_t** spriteQueue,
                                const char* spriteName) {
    if (spriteName == nullptr || spriteName[0] == '\0') return false;
    repeat(dataWin->sprt.count, i) {
        const char* name = dataWin->sprt.sprites[i].name;
        if (name != nullptr && strcmp(name, spriteName) == 0) {
            return queueSpriteIndexOnce(dataWin, seen, spriteQueue, (int32_t)i);
        }
    }
    return false;
}

static bool rvalueToLikelySpriteIndex(RValue value, int32_t* outSpriteIndex) {
    GMLReal n;
    switch (value.type) {
        case RVALUE_REAL:
            n = value.real;
            if (GMLReal_fabs(n - GMLReal_round(n)) > 0.001) return false;
            *outSpriteIndex = (int32_t)GMLReal_round(n);
            return true;
        case RVALUE_INT32:
#ifndef NO_RVALUE_INT64
        case RVALUE_INT64:
#endif
            *outSpriteIndex = RValue_toInt32(value);
            return true;
        default:
            return false;
    }
}

static void queueSpriteRefsFromValue(DataWin* dataWin, bool* seen, int32_t** spriteQueue,
                                     RValue value) {
    int32_t spriteIndex = -1;
    if (rvalueToLikelySpriteIndex(value, &spriteIndex)) {
        queueSpriteIndexOnce(dataWin, seen, spriteQueue, spriteIndex);
        return;
    }

    if (value.type != RVALUE_ARRAY || value.array == nullptr) return;
    GMLArray* arr = value.array;
    for (int32_t row = 0; row < arr->rowCount; row++) {
        GMLArrayRow* r = &arr->rows[row];
        for (int32_t col = 0; col < r->length; col++) {
            if (rvalueToLikelySpriteIndex(r->data[col], &spriteIndex)) {
                queueSpriteIndexOnce(dataWin, seen, spriteQueue, spriteIndex);
            }
        }
    }
}

static uint32_t Runner_prefetchRuntimeSprites(Runner* runner) {
    if (runner == nullptr || runner->renderer == nullptr ||
        (runner->renderer->vtable->prefetchSprite == nullptr &&
         runner->renderer->vtable->prefetchSprites == nullptr)) {
        return 0;
    }

    DataWin* dataWin = runner->dataWin;
    bool* seen = calloc(dataWin->sprt.count ? dataWin->sprt.count : 1, sizeof(bool));
    int32_t* spriteQueue = nullptr;

    repeat(arrlen(runner->instances), i) {
        Instance* inst = runner->instances[i];
        if (inst == nullptr) continue;

        if (inst->active && inst->visible) {
            queueSpriteIndexOnce(dataWin, seen, &spriteQueue, inst->spriteIndex);
        }

        if (inst->active && (inst->visible || isMaincharaInstance(dataWin, inst))) {
            repeat(inst->selfVars.capacity, slot) {
                IntRValueEntry* entry = &inst->selfVars.entries[slot];
                if (entry->key == INT_RVALUE_HASHMAP_EMPTY_KEY) continue;
                if (!varIdLooksLikeSpriteRef(dataWin, entry->key)) continue;
                queueSpriteRefsFromValue(dataWin, seen, &spriteQueue, entry->value);
                if (arrlenu(spriteQueue) >= 160) break;
            }
        }
        if (arrlenu(spriteQueue) >= 160) break;
    }

    repeat(arrlenu(runner->runtimeLayers), layerIndex) {
        RuntimeLayer* layer = &runner->runtimeLayers[layerIndex];
        if (!layer->visible) continue;
        repeat(arrlenu(layer->elements), elIndex) {
            RuntimeLayerElement* el = &layer->elements[elIndex];
            if (el->type == RuntimeLayerElementType_Sprite && el->spriteElement != nullptr) {
                queueSpriteIndexOnce(dataWin, seen, &spriteQueue, el->spriteElement->spriteIndex);
            }
        }
    }

    uint32_t prefetchedCount = (uint32_t)arrlenu(spriteQueue);
    if (prefetchedCount > 0) {
        if (runner->renderer->vtable->prefetchSprites != nullptr) {
            runner->renderer->vtable->prefetchSprites(runner->renderer, spriteQueue, prefetchedCount);
        } else {
            repeat(prefetchedCount, i) {
                runner->renderer->vtable->prefetchSprite(runner->renderer, spriteQueue[i]);
            }
        }
    }

    arrfree(spriteQueue);
    free(seen);
    if (prefetchedCount > 0) {
#if CTR_OPT_DIAGNOSTICS
        fprintf(stderr, "Runner: runtime sprite preload touched %lu sprites\n",
                (unsigned long)prefetchedCount);
#endif
    }
    return prefetchedCount;
}

static uint32_t Runner_prefetchInstanceSprites(Runner* runner, Instance* inst) {
    if (runner == nullptr || inst == nullptr || runner->renderer == nullptr ||
        (runner->renderer->vtable->prefetchSprite == nullptr &&
         runner->renderer->vtable->prefetchSprites == nullptr)) {
        return 0;
    }

    DataWin* dataWin = runner->dataWin;
    bool* seen = calloc(dataWin->sprt.count ? dataWin->sprt.count : 1, sizeof(bool));
    int32_t* spriteQueue = nullptr;

    queueSpriteIndexOnce(dataWin, seen, &spriteQueue, inst->spriteIndex);
    if (inst->maskIndex >= 0) queueSpriteIndexOnce(dataWin, seen, &spriteQueue, inst->maskIndex);

    repeat(inst->selfVars.capacity, slot) {
        IntRValueEntry* entry = &inst->selfVars.entries[slot];
        if (entry->key == INT_RVALUE_HASHMAP_EMPTY_KEY) continue;
        if (!varIdLooksLikeSpriteRef(dataWin, entry->key)) continue;
        queueSpriteRefsFromValue(dataWin, seen, &spriteQueue, entry->value);
        if (arrlenu(spriteQueue) >= 32) break;
    }

    if (runner->gameProfile == GAME_PROFILE_DELTARUNE &&
        inst->objectIndex >= 0 && (uint32_t)inst->objectIndex < dataWin->objt.count) {
        const char* objectName = dataWin->objt.objects[inst->objectIndex].name;
        if (objectName != nullptr && strcmp(objectName, "obj_tensionbar") == 0) {
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_tensionbar");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_tensionbar_cutout");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_tensionmarker");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_tplogo");
        } else if (objectName != nullptr && strcmp(objectName, "obj_teacup") == 0) {
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_screw");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_screw_end");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_base");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_platform");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_center");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacuparrow");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_empty");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_kris");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_susie");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_ralsei");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_tea");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_tea2");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_kris_tea");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_kris_tea2");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_susie_tea");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_ralsei_tea");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_ralsei_tea2");
        } else if (objectName != nullptr && strcmp(objectName, "obj_teacup_bullet") == 0) {
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_bullet");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_bullet_big");
            queueSpriteNameOnce(dataWin, seen, &spriteQueue, "spr_teacup_bullet_good");
        }
    }

    uint32_t prefetchedCount = (uint32_t)arrlenu(spriteQueue);
    if (prefetchedCount > 0) {
        if (runner->renderer->vtable->prefetchSprites != nullptr) {
            runner->renderer->vtable->prefetchSprites(runner->renderer, spriteQueue, prefetchedCount);
        } else {
            repeat(prefetchedCount, i) {
                runner->renderer->vtable->prefetchSprite(runner->renderer, spriteQueue[i]);
            }
        }
    }

    arrfree(spriteQueue);
    free(seen);
    return prefetchedCount;
}

static void initRoom(Runner* runner, int32_t roomIndex) {
    DataWin* dataWin = runner->dataWin;
    require(roomIndex >= 0 && dataWin->room.count > (uint32_t) roomIndex);

    Room* room = &dataWin->room.rooms[roomIndex];

    // Lazy-room load: if the payload wasn't loaded, read it from the data.win file now before anything touches the room's game objects/tiles/layers.
    if (!room->payloadLoaded) {
        DataWin_loadRoomPayload(dataWin, roomIndex);
    }

    if (runner->renderer != nullptr && runner->renderer->vtable->onRoomChanged != nullptr) {
        runner->renderer->vtable->onRoomChanged(runner->renderer, roomIndex);
    }

    SavedRoomState* savedState = &runner->savedRoomStates[roomIndex];

    runner->currentRoom = room;
    runner->currentRoomIndex = roomIndex;
    runner->viewsEnabled = (room->flags & 1) != 0;
    // Tile set, runtime layers, and instance list all change when entering a room.
    runner->drawableListStructureDirty = true;
    // It could be the first time we are initializing the grid
    if (runner->spatialGrid != nullptr)
        SpatialGrid_free(runner->spatialGrid);
    runner->spatialGrid = SpatialGrid_create(room->width, room->height);

    // Find position in room order
    runner->currentRoomOrderPosition = -1;
    repeat(dataWin->gen8.roomOrderCount, i) {
        if (dataWin->gen8.roomOrder[i] == roomIndex) {
            runner->currentRoomOrderPosition = (int32_t) i;
            break;
        }
    }

    // If this is a persistent room that was previously visited, restore saved state
    if (room->persistent && savedState->initialized) {
        memcpy(runner->views, savedState->views, sizeof(runner->views));
        runner->viewsEnabled = savedState->viewsEnabled;
        memcpy(runner->defaultCameras, savedState->defaultCameras, sizeof(runner->defaultCameras));

        // Restore backgrounds from saved state
        memcpy(runner->backgrounds, savedState->backgrounds, sizeof(runner->backgrounds));
        runner->backgroundColor = savedState->backgroundColor;
        runner->drawBackgroundColor = savedState->drawBackgroundColor;

        // Restore tile layer map
        hmfree(runner->tileLayerMap);
        runner->tileLayerMap = savedState->tileLayerMap;
        savedState->tileLayerMap = nullptr;

        // Restore runtime layers
        freeRuntimeLayersArray(&runner->runtimeLayers);
        runner->runtimeLayers = savedState->runtimeLayers;
        savedState->runtimeLayers = nullptr;

        Instance** carriedPersistent = takePersistentInstances(runner);

        // The native runner restores the room's own linked list first, then appends persistent arrivals at the tail.
        // Event iteration is forward (oldest first), so a persistent instance runs after the room's own instances.
        int32_t savedCount = (int32_t) arrlen(savedState->instances);
        repeat(savedCount, i) {
            arrput(runner->instances, savedState->instances[i]);
            Runner_addInstanceToObjectLists(runner, savedState->instances[i]);
        }
        arrfree(savedState->instances);
        savedState->instances = nullptr;

        returnPersistentInstances(runner, carriedPersistent);

        // No Create events, no preCreateCode, no creationCode, no room creation code
        fprintf(stderr, "Runner: Room restored (persistent): %s (room %d) with %d instances\n", room->name, roomIndex, (int) arrlen(runner->instances));
        return;
    }

    // === Normal room initialization (first visit, or non-persistent room) ===

    // Initialize the views from scratch
    repeat(MAX_VIEWS, vi) {
        copyRoomViewToRuntimeView(&room->views[vi], &runner->views[vi]);
        runner->views[vi].cameraId = (int32_t) vi;
        initDefaultCameraFromRoomView(&runner->defaultCameras[vi], &room->views[vi]);
    }

    // Reset tile layer state for the new room
    hmfree(runner->tileLayerMap);
    runner->tileLayerMap = nullptr;

    // Populate runtime layers from parsed room layers (GMS2+ only; empty for GMS1.x).
    // Dynamic layers created via layer_create are appended to this array later.
    freeRuntimeLayersArray(&runner->runtimeLayers);
    uint32_t maxLayerId = 0;
    repeat(room->layerCount, i) {
        RoomLayer* layerSource = &room->layers[i];
        RuntimeLayer runtimeLayer = {
            .id = layerSource->id,
            .depth = layerSource->depth,
            .visible = layerSource->visible,
            .xOffset = layerSource->xOffset,
            .yOffset = layerSource->yOffset,
            .hSpeed = layerSource->hSpeed,
            .vSpeed = layerSource->vSpeed,
            .dynamic = false,
            .dynamicName = nullptr,
            .elements = nullptr,
        };
        arrput(runner->runtimeLayers, runtimeLayer);
        if (layerSource->id > maxLayerId) maxLayerId = layerSource->id;
    }
    // Watermark: ensure runtime-allocated IDs (layers + elements) stay above parsed IDs.
    if (maxLayerId >= runner->nextLayerId) runner->nextLayerId = maxLayerId + 1;

    // Populate runtime sprite elements for Assets layers, so they can be queried and destroyed via layer_sprite_get_sprite/layer_sprite_destroy
    repeat(room->layerCount, i) {
        RoomLayer* layerSource = &room->layers[i];
        if (layerSource->type != RoomLayerType_Assets || layerSource->assetsData == nullptr) continue;
        RoomLayerAssetsData* assets = layerSource->assetsData;
        RuntimeLayer* runtimeLayer = &runner->runtimeLayers[i];
        repeat(assets->spriteCount, j) {
            SpriteInstance* src = &assets->sprites[j];
            RuntimeSpriteElement* spriteElement = safeMalloc(sizeof(RuntimeSpriteElement));
            spriteElement->spriteIndex = src->spriteIndex;
            spriteElement->x = src->x;
            spriteElement->y = src->y;
            spriteElement->scaleX = src->scaleX;
            spriteElement->scaleY = src->scaleY;
            spriteElement->color = src->color;
            spriteElement->animationSpeed = src->animationSpeed;
            spriteElement->animationSpeedType = src->animationSpeedType;
            spriteElement->frameIndex = src->frameIndex;
            spriteElement->rotation = src->rotation;
            RuntimeLayerElement el = {
                .id = Runner_getNextLayerId(runner),
                .type = RuntimeLayerElementType_Sprite,
                .visible = true,
                .alpha = 1.0f,
                .backgroundElement = nullptr,
                .spriteElement = spriteElement,
                .tileElement = nullptr,
                .tilemapElement = nullptr,
                .tilemapLayerId = 0,
            };
            arrput(runtimeLayer->elements, el);
        }
        if (runner->gameProfile == GAME_PROFILE_DELTARUNE) {
            repeat(assets->legacyTileCount, j) {
                RoomTile* tile = &assets->legacyTiles[j];
                RuntimeLayerElement el = {
                    .id = Runner_getNextLayerId(runner),
                    .type = RuntimeLayerElementType_Tile,
                    .visible = true,
                    .alpha = 1.0f,
                    .backgroundElement = nullptr,
                    .spriteElement = nullptr,
                    .tileElement = tile,
                    .tilemapElement = nullptr,
                    .tilemapLayerId = 0,
                };
                arrput(runtimeLayer->elements, el);
            }
        }
    }

    // Populate GMS2 tilemap elements for parsed tile layers. Deltarune scripts
    // query these through layer_get_all_elements() / layer_tilemap_get_id().
    repeat(room->layerCount, i) {
        RoomLayer* layerSource = &room->layers[i];
        if (layerSource->type != RoomLayerType_Tiles || layerSource->tilesData == nullptr) continue;
        RuntimeLayer* runtimeLayer = &runner->runtimeLayers[i];
        RuntimeLayerElement el = {
            .id = Runner_getNextLayerId(runner),
            .type = RuntimeLayerElementType_Tilemap,
            .visible = true,
            .alpha = 1.0f,
            .backgroundElement = nullptr,
            .spriteElement = nullptr,
            .tileElement = nullptr,
            .tilemapElement = layerSource->tilesData,
            .tilemapLayerId = layerSource->id,
        };
        arrput(runtimeLayer->elements, el);
    }

    // Populate mutable background elements for parsed GMS2 background layers.
    // Deltarune's compatibility scripts query and mutate these through the
    // layer_background_* API, so parsed backgrounds need runtime element IDs too.
    repeat(room->layerCount, i) {
        RoomLayer* layerSource = &room->layers[i];
        if (layerSource->type != RoomLayerType_Background || layerSource->backgroundData == nullptr) continue;
        RoomLayerBackgroundData* src = layerSource->backgroundData;
        RuntimeLayer* runtimeLayer = &runner->runtimeLayers[i];

        RuntimeBackgroundElement* bg = safeMalloc(sizeof(RuntimeBackgroundElement));
        bg->spriteIndex = src->spriteIndex;
        bg->visible = src->visible;
        bg->htiled = src->hTiled;
        bg->vtiled = src->vTiled;
        bg->stretch = src->stretch;
        bg->xScale = 1.0f;
        bg->yScale = 1.0f;
        bg->blend = src->color & 0x00FFFFFFu;
        bg->alpha = 1.0f;
        bg->xOffset = 0.0f;
        bg->yOffset = 0.0f;
        bg->frameIndex = src->firstFrame;
        bg->animationSpeed = src->animSpeed;
        bg->animationSpeedType = src->animSpeedType;

        RuntimeLayerElement el = {
            .id = Runner_getNextLayerId(runner),
            .type = RuntimeLayerElementType_Background,
            .visible = true,
            .alpha = 1.0f,
            .backgroundElement = bg,
            .spriteElement = nullptr,
            .tileElement = nullptr,
            .tilemapElement = nullptr,
            .tilemapLayerId = 0,
        };
        arrput(runtimeLayer->elements, el);
    }

    // Copy room background definitions into mutable runtime state
    runner->backgroundColor = room->backgroundColor;
    runner->drawBackgroundColor = room->drawBackgroundColor;
    repeat(8, i) {
        RoomBackground* src = &room->backgrounds[i];
        RuntimeBackground* dst = &runner->backgrounds[i];
        dst->visible = src->enabled;
        dst->foreground = src->foreground;
        dst->backgroundIndex = src->backgroundDefinition;
        dst->x = (float) src->x;
        dst->y = (float) src->y;
        dst->tileX = (bool) src->tileX;
        dst->tileY = (bool) src->tileY;
        dst->speedX = (float) src->speedX;
        dst->speedY = (float) src->speedY;
        dst->stretch = src->stretch;
        dst->alpha = 1.0f;
    }

    Instance** carriedPersistent = takePersistentInstances(runner);

    // Two-pass instance creation (matches HTML5 runner behavior):
    // Pass 1: Create all instance objects so they exist for cross-references
    // Pass 2: Fire preCreateCode, CREATE events, and creationCode
    // This ensures that when an instance's Create event reads another instance
    // (e.g. obj_mainchara reading obj_markerA.x), the target already exists.

    // Pass 1: Create all instances without firing events
    repeat(room->gameObjectCount, i) {
        RoomGameObject* roomObj = &room->gameObjects[i];

        // Skip if a persistent instance carried over from the previous room already owns this ID (re-entering the persistent instance's home room, don't create a duplicate!).
        if (hmget(runner->instancesById, roomObj->instanceID) != nullptr) continue;
        if (isObjectDisabled(runner, roomObj->objectDefinition)) continue;

        Instance* inst = createAndInitInstance(runner, roomObj->instanceID, roomObj->objectDefinition, (GMLReal) roomObj->x, (GMLReal) roomObj->y);
        inst->imageXscale = (float) roomObj->scaleX;
        inst->imageYscale = (float) roomObj->scaleY;
        inst->imageAngle = (float) roomObj->rotation;
        inst->imageSpeed = roomObj->imageSpeed;
        inst->imageIndex = (float) roomObj->imageIndex;
    }

    // In GMS2, instances get their depth from their room layer, not the object definition.
    // This must happen before firing Create events so scripts like scr_depth() read the layer depth.
    if (DataWin_isVersionAtLeast(runner->dataWin, 2, 0, 0, 0)) {
        repeat(room->layerCount, li) {
            RoomLayer* layer = &room->layers[li];
            if (layer->type != RoomLayerType_Instances || layer->instancesData == nullptr) continue;
            RoomLayerInstancesData* layerData = layer->instancesData;
            repeat(layerData->instanceCount, ii) {
                Instance* inst = hmget(runner->instancesById, layerData->instanceIds[ii]);
                if (inst != nullptr) {
                    inst->depth = layer->depth;
                    inst->layer = (int32_t) layer->id;
                }
            }
        }
    }

    // Append persistent instances carried over from the previous room at the tail, so forward event iteration processes the new room's own instances first and the travelers last.
    // We NEED to do this here BEFORE firing the room object's events, to avoid code that relies on persistent instances failing (example: if a object uses instance_number to get the number of instances in the room).
    returnPersistentInstances(runner, carriedPersistent);

    // Pass 2: Fire events for newly created instances (in room definition order)
    repeat(room->gameObjectCount, i) {
        RoomGameObject* roomObj = &room->gameObjects[i];

        Instance* inst = hmget(runner->instancesById, roomObj->instanceID);
        if (inst == nullptr) continue;

        // Skip instances that already had their Create event fired (persistent carry-overs
        // that hmget also matches, since instancesById still holds them).
        if (inst->createEventFired) continue;
        inst->createEventFired = true;

        Runner_executeEvent(runner, inst, EVENT_PRECREATE, 0);
        executeCode(runner, inst, roomObj->preCreateCode);
        Runner_executeEvent(runner, inst, EVENT_CREATE, 0);
        executeCode(runner, inst, roomObj->creationCode);
    }

    // Run room creation code
    if (room->creationCodeId >= 0 && dataWin->code.count > (uint32_t) room->creationCodeId) {
        // Room creation code runs in global context, the native runner creates a fake/dummy instance for the "self"
        Instance* dummy = Instance_create(0, -1, 0, 0);
        runner->vmContext->currentInstance = dummy;
        RValue result = VM_executeCode(runner->vmContext, room->creationCodeId);
        RValue_free(&result);
        runner->vmContext->currentInstance = nullptr;
        Instance_free(dummy);
    }

    // Mark this room as initialized for persistent room support
    savedState->initialized = true;

    fprintf(stderr, "Runner: Room loaded: %s (room %d) with %d instances\n", room->name, roomIndex, (int) arrlen(runner->instances));
}

// Cleans up the runner state, used when freeing the Runner or when restarting the Runner
static void cleanupState(Runner* runner) {
    // Drop VM-side RValue holders (globals, stack, call frames) BEFORE freeing any Instance memory. This way any RVALUE_STRUCT refs decrement against still-live struct memory; otherwise we'd free a struct here and then have VM_free's later VM_reset try to decRef a dangling pointer.
    if (runner->vmContext != nullptr) {
        VM_reset(runner->vmContext);
    }

    // Free all instances
    repeat(arrlen(runner->instances), i) {
        hmdel(runner->instancesById, runner->instances[i]->instanceId);
        Instance_free(runner->instances[i]);
    }
    arrfree(runner->instances);
    runner->instances = nullptr;

    // Empty the per-object lists. We keep the outer instancesByObject array allocated so Runner_reset can be reused; Runner_free releases it.
    Runner_clearAllObjectLists(runner);

    // Free saved room states
    if (runner->savedRoomStates != nullptr) {
        repeat(runner->dataWin->room.count, i) {
            SavedRoomState* state = &runner->savedRoomStates[i];
            int32_t savedCount = (int32_t) arrlen(state->instances);
            repeat(savedCount, j) {
                hmdel(runner->instancesById, state->instances[j]->instanceId);
                Instance_free(state->instances[j]);
            }
            arrfree(state->instances);
            hmfree(state->tileLayerMap);
            freeRuntimeLayersArray(&state->runtimeLayers);
        }
        free(runner->savedRoomStates);
    }
    runner->savedRoomStates = nullptr;

    // Free struct instances (created via @@NewGMLObject@@). Anything still here at shutdown is leaked refs or a reference cycle - bulk free regardless of refCount.
    repeat(arrlen(runner->structInstances), i) {
        Instance* s = runner->structInstances[i];
        hmdel(runner->instancesById, s->instanceId);
        s->structRegistryIndex = -1;
        Instance_free(s);
    }
    arrfree(runner->structInstances);
    runner->structInstances = nullptr;

    hmfree(runner->instancesById);
    runner->instancesById = nullptr;
    hmfree(runner->tileLayerMap);
    runner->tileLayerMap = nullptr;
    freeRuntimeLayersArray(&runner->runtimeLayers);
    shfree(runner->disabledObjects);
    runner->disabledObjects = nullptr;

    // Free ds_map pool
    repeat((int32_t) arrlen(runner->dsMapPool), i) {
        DsMapEntry* map = runner->dsMapPool[i];
        if (map != nullptr) {
            repeat(shlen(map), j) {
                free(map[j].key);
                RValue_free(&map[j].value);
            }
            shfree(map);
        }
    }
    arrfree(runner->dsMapPool);
    runner->dsMapPool = nullptr;

    // Free ds_list pool
    repeat((int32_t) arrlen(runner->dsListPool), i) {
        DsList* list = &runner->dsListPool[i];
        repeat(arrlen(list->items), j) {
            RValue_free(&list->items[j]);
        }
        arrfree(list->items);
    }
    arrfree(runner->dsListPool);
    runner->dsListPool = nullptr;

    // Free ds_priority pool
    repeat((int32_t) arrlen(runner->dsPriorityPool), i) {
        DsPriority* priority = &runner->dsPriorityPool[i];
        repeat(arrlen(priority->items), j) {
            RValue_free(&priority->items[j].value);
        }
        arrfree(priority->items);
    }
    arrfree(runner->dsPriorityPool);
    runner->dsPriorityPool = nullptr;

    // Free mp_grid pool
    repeat((int32_t) arrlen(runner->mpGridPool), i) {
        free(runner->mpGridPool[i].cells);
    }
    arrfree(runner->mpGridPool);
    runner->mpGridPool = nullptr;

    // Free INI state
    if (runner->currentIni != nullptr) {
        Ini_free(runner->currentIni);
        runner->currentIni = nullptr;
    }
    free(runner->currentIniPath);
    runner->currentIniPath = nullptr;
    if (runner->cachedIni != nullptr) {
        Ini_free(runner->cachedIni);
        runner->cachedIni = nullptr;
    }
    free(runner->cachedIniPath);
    runner->cachedIniPath = nullptr;

    // Free open text files
    repeat(MAX_OPEN_TEXT_FILES, i) {
        OpenTextFile* file = &runner->openTextFiles[i];
        if (file->isOpen) {
            free(file->content);
            free(file->writeBuffer);
            free(file->filePath);
            *file = (OpenTextFile) {0};
        }
    }

    if (runner->spatialGrid != nullptr) {
        SpatialGrid_free(runner->spatialGrid);
        runner->spatialGrid = nullptr;
    }
}

// ===[ Public API ]===

void Runner_reset(Runner* runner) {
    // This actually sets the default runner values, used for initialization and restarting
    cleanupState(runner);

    // Reset VM state
    VM_reset(runner->vmContext);

    runner->pendingRoom = -1;
    runner->asyncLoadMapId = -1;
    runner->gameStartFired = false;
    runner->currentRoomIndex = -1;
    runner->currentRoomOrderPosition = -1;
    runner->nextInstanceId = runner->dataWin->gen8.lastObj + 1;
    runner->savedRoomStates = safeCalloc(runner->dataWin->room.count, sizeof(SavedRoomState));
    runner->nextLayerId = 1;
    runner->viewsEnabled = false;
    memset(runner->views, 0, sizeof(runner->views));
    memset(runner->defaultCameras, 0, sizeof(runner->defaultCameras));
    memset(runner->userCameras, 0, sizeof(runner->userCameras));
    runner->audioSystem->vtable->stopAll(runner->audioSystem);

    // Allocate the per-object instance list array once.
    // We don't need to reinitialize the list because the objt.count is fixed for this data.win.
    if (runner->instancesByObject == nullptr) {
        runner->instancesByObject = safeCalloc(runner->dataWin->objt.count, sizeof(Instance**));
    }
    if (runner->instancesByExactObject == nullptr) {
        runner->instancesByExactObject = safeCalloc(runner->dataWin->objt.count, sizeof(Instance**));
    }

    // Create the instance used for "self" in GLOB scripts
    Instance_free(runner->globalScopeInstance);
    runner->globalScopeInstance = Instance_create(0, -1, 0, 0);

    // Reset builtin function state
    runner->mpPotMaxrot = 30.0;
    runner->mpPotStep = 10.0;
    runner->mpPotAhead = 3.0;
    runner->mpPotOnSpot = true;
    runner->lastMusicInstance = -1;

    arrsetlen(runner->cachedDrawables, 0);
    runner->drawableListStructureDirty = true;
    runner->drawableListSortDirty = false;
}

// Populates objectsWithAnyEventOfType[eventType] from the resolved event table: for each event type, the deduplicated list of concrete object indices that respond to ANY subtype of that event. Walks the inverted bySlot index per slot and dedups via a scratch byte set.
// Used by collision dispatch to skip non-collision objects in the outer loop, mirroring how the native obj_has_event table partitions instance iteration by event class.
static void populateObjectsWithAnyEventOfType(Runner* runner) {
    int32_t objectCount = (int32_t) runner->dataWin->objt.count;
    runner->objectsWithAnyEventOfType = safeCalloc(OBJT_EVENT_TYPE_COUNT, sizeof(int32_t*));
    if (objectCount == 0) return;

    uint8_t* seen = safeCalloc((size_t) objectCount, 1);

    repeat(OBJT_EVENT_TYPE_COUNT, t) {
        int16_t* dense = runner->eventSlotMap.denseLookup[t];
        if (dense == nullptr) continue;
        int32_t maxSub = runner->eventSlotMap.maxSubtypeByType[t];
        memset(seen, 0, (size_t) objectCount);

        for (int32_t sub = 0; maxSub >= sub; sub++) {
            int32_t slot = dense[sub];
            if (0 > slot) continue;
            uint32_t entryCount;
            SlotResponderEntry* entries = ResolvedEventTable_slotEntries(&runner->eventTable, slot, &entryCount);
            repeat(entryCount, i) {
                int32_t obj = entries[i].concreteObjectId;
                if (obj < 0 || obj >= objectCount) continue;
                if (seen[obj]) continue;
                seen[obj] = 1;
                arrput(runner->objectsWithAnyEventOfType[t], obj);
            }
        }
    }

    free(seen);
}

Runner* Runner_create(DataWin* dataWin, VMContext* vm, Renderer* renderer, FileSystem* fileSystem, AudioSystem* audioSystem, GameProfile gameProfile) {
    requireNotNull(dataWin);
    requireNotNull(vm);
    requireNotNull(renderer);
    requireNotNull(fileSystem);
    requireNotNull(audioSystem);

    Runner* runner = safeCalloc(1, sizeof(Runner));
    runner->dataWin = dataWin;

    runner->vmContext = vm;
    runner->renderer = renderer;
    runner->fileSystem = fileSystem;
    runner->audioSystem = audioSystem;
    runner->gameProfile = gameProfile;
    renderer->gameProfile = gameProfile;
    runner->frameCount = 0;
    runner->osType = OS_WINDOWS;
    runner->keyboard = RunnerKeyboard_create();
    runner->mouse = RunnerMouse_create();
    runner->gamepads = RunnerGamepad_create();

    // Collision compatibility mode is "enabled" for all pre-GM 2022.1 games AND for any post-GM 2022.1 games that have the bit 27 set
    runner->collisionCompatibilityMode = (dataWin->detectedFormat.major == 1) || (((dataWin->optn.info >> 27) & 1) != 0);

    // Build the event dispatch acceleration tables.
    EventSlotMap_build(&runner->eventSlotMap, dataWin);
    ResolvedEventTable_build(&runner->eventTable, dataWin, &runner->eventSlotMap);

    // Create assets map
    shdefault(runner->assetsByName, -1);
    repeat(dataWin->objt.count, i) {
        shput(runner->assetsByName, dataWin->objt.objects[i].name, i);
    }
    repeat(dataWin->sprt.count, i) {
        shput(runner->assetsByName, dataWin->sprt.sprites[i].name, i);
    }
    repeat(dataWin->sond.count, i) {
        shput(runner->assetsByName, dataWin->sond.sounds[i].name, i);
    }
    repeat(dataWin->bgnd.count, i) {
        shput(runner->assetsByName, dataWin->bgnd.backgrounds[i].name, i);
    }
    repeat(dataWin->path.count, i) {
        shput(runner->assetsByName, dataWin->path.paths[i].name, i);
    }
    repeat(dataWin->scpt.count, i) {
        shput(runner->assetsByName, dataWin->scpt.scripts[i].name, i);
    }
    repeat(dataWin->font.count, i) {
        shput(runner->assetsByName, dataWin->font.fonts[i].name, i);
    }
    repeat(dataWin->tmln.count, i) {
        shput(runner->assetsByName, dataWin->tmln.timelines[i].name, i);
    }
    repeat(dataWin->room.count, i) {
        shput(runner->assetsByName, dataWin->room.rooms[i].name, i);
    }

    Runner_reset(runner);

    populateObjectsWithAnyEventOfType(runner);

    // Link runner to VM context
    vm->runner = (struct Runner*) runner;

    // Native script overrides are game-specific. Keep Undertale's optimized
    // handlers from leaking into Deltarune when returning through the launcher.
    NativeScripts_reset();
    if (runner->gameProfile == GAME_PROFILE_UNDERTALE) {
        NativeScripts_init(vm, runner);
    }

    renderer->vtable->init(renderer, dataWin);
    audioSystem->vtable->init(audioSystem, dataWin, fileSystem);

    return runner;
}

static inline void dispatchInstanceCreationEvents(Runner* runner, Instance* inst) {
    inst->createEventFired = true;
    Runner_executeEvent(runner, inst, EVENT_PRECREATE, 0);
    Runner_executeEvent(runner, inst, EVENT_CREATE, 0);
    if (runner->gameProfile == GAME_PROFILE_DELTARUNE) {
        Runner_prefetchInstanceSprites(runner, inst);
    }
}

Instance* Runner_createInstance(Runner* runner, GMLReal x, GMLReal y, int32_t objectIndex) {
    if (isObjectDisabled(runner, objectIndex)) return nullptr;
    Instance* inst = createAndInitInstance(runner, runner->nextInstanceId++, objectIndex, x, y);
    dispatchInstanceCreationEvents(runner, inst);
    return inst;
}

// Same as Runner_createInstance, but sets depth BEFORE firing Create events so scripts like scr_depth can override.
Instance* Runner_createInstanceWithDepth(Runner* runner, GMLReal x, GMLReal y, int32_t objectIndex, int32_t depth) {
    if (isObjectDisabled(runner, objectIndex)) return nullptr;
    Instance* inst = createAndInitInstance(runner, runner->nextInstanceId++, objectIndex, x, y);
    inst->depth = depth;
    dispatchInstanceCreationEvents(runner, inst);
    return inst;
}

Instance* Runner_createInstanceWithLayer(Runner* runner, GMLReal x, GMLReal y, int32_t objectIndex, int32_t layerId) {
    if (isObjectDisabled(runner, objectIndex)) return nullptr;
    RuntimeLayer* rl = Runner_findRuntimeLayerById(runner, layerId);
    if (rl == nullptr) {
        fprintf(stderr, "Runner: instance_create_layer: Layer ID %d not found!\n", layerId);
        return nullptr;
    }
    Instance* inst = createAndInitInstance(runner, runner->nextInstanceId++, objectIndex, x, y);
    inst->layer = layerId;
    inst->depth = rl->depth;
    dispatchInstanceCreationEvents(runner, inst);
    return inst;
}

Instance* Runner_copyInstance(Runner* runner, Instance* source, bool performEvent) {
    requireNotNull(source);
    if (isObjectDisabled(runner, source->objectIndex)) return nullptr;

    Instance* inst = createAndInitInstance(runner, runner->nextInstanceId++, source->objectIndex, source->x, source->y);
    Instance_copyFields(inst, source);
    inst->createEventFired = true;
    if (performEvent) {
        Runner_executeEvent(runner, inst, EVENT_PRECREATE, 0);
        Runner_executeEvent(runner, inst, EVENT_CREATE, 0);
    }
    return inst;
}

void Runner_destroyInstance(MAYBE_UNUSED Runner* runner, Instance* inst) {
    Runner_executeEvent(runner, inst, EVENT_DESTROY, 0);
    // A destroyed instance must ALWAYS be not active
    // If a destroyed instance is active, then well, something went VERY wrong
    inst->active = false;
    inst->destroyed = true;

#ifdef ENABLE_VM_TRACING
    GameObject* gameObject = &runner->dataWin->objt.objects[inst->objectIndex];
    if (shgeti(runner->vmContext->instanceLifecyclesToBeTraced, "*") != -1 || shgeti(runner->vmContext->instanceLifecyclesToBeTraced, gameObject->name) != -1) {
        fprintf(stderr, "VM: Instance %s (instanceId=%d,objectIndex=%d) destroyed\n", gameObject->name, inst->instanceId, inst->objectIndex);
    }
#endif
}

RuntimeLayer* Runner_findRuntimeLayerById(Runner* runner, int32_t id) {
    size_t count = arrlenu(runner->runtimeLayers);
    repeat(count, i) {
        if ((int32_t) runner->runtimeLayers[i].id == id)
            return &runner->runtimeLayers[i];
    }
    return nullptr;
}

RoomLayer* Runner_findRoomLayerById(Runner* runner, int32_t id) {
    if (runner->currentRoom == nullptr) return nullptr;
    repeat(runner->currentRoom->layerCount, i) {
        if ((int32_t) runner->currentRoom->layers[i].id == id) return &runner->currentRoom->layers[i];
    }
    return nullptr;
}

RuntimeLayerElement* Runner_findLayerElementById(Runner* runner, int32_t elementId, RuntimeLayer** outLayer) {
    size_t layerCount = arrlenu(runner->runtimeLayers);
    repeat(layerCount, i) {
        RuntimeLayer* runtimeLayer = &runner->runtimeLayers[i];
        size_t elementCount = arrlenu(runtimeLayer->elements);
        repeat(elementCount, j) {
            if ((int32_t) runtimeLayer->elements[j].id == elementId) {
                if (outLayer != nullptr) {
                    *outLayer = runtimeLayer;
                }

                return &runtimeLayer->elements[j];
            }
        }
    }
    if (outLayer != nullptr) *outLayer = nullptr;
    return nullptr;
}

GMLCamera* Runner_getCameraById(Runner* runner, int32_t id) {
    if (runner == nullptr) return nullptr;
    if (id >= 0 && MAX_DEFAULT_ROOM_CAMERAS > id) {
        GMLCamera* camera = &runner->defaultCameras[id];
        return camera->allocated ? camera : nullptr;
    }
    if (id >= MAX_DEFAULT_ROOM_CAMERAS && MAX_CAMERAS > id) {
        GMLCamera* camera = &runner->userCameras[id - MAX_DEFAULT_ROOM_CAMERAS];
        return camera->allocated ? camera : nullptr;
    }
    return nullptr;
}

GMLCamera* Runner_getCameraForView(Runner* runner, int32_t viewIndex) {
    if (runner == nullptr || viewIndex < 0 || MAX_VIEWS <= viewIndex) return nullptr;
    return Runner_getCameraById(runner, runner->views[viewIndex].cameraId);
}

uint32_t Runner_getNextLayerId(Runner* runner) {
    return runner->nextLayerId++;
}

// Reaps GML structs whose only remaining ref is the structInstances registry's implicit +1.
// Walks backward so that swap-remove of dead entries doesn't disturb the indexes of entries we haven't visited yet.
static void Runner_sweepDeadStructs(Runner* runner) {
    int32_t count = (int32_t) arrlen(runner->structInstances);
    for (int32_t i = count - 1; i >= 0; i--) {
        Instance* s = runner->structInstances[i];
        if (s->refCount > 1) continue; // still referenced by user code
        require(s->refCount == 1);

        // Remove from runner->instancesById so future findInstanceByTarget(id) returns nullptr.
        hmdel(runner->instancesById, s->instanceId);

        // O(1) swap-remove from structInstances, keeping structRegistryIndex in sync.
        int32_t lastIdx = (int32_t) arrlen(runner->structInstances) - 1;
        if (i != lastIdx) {
            Instance* moved = runner->structInstances[lastIdx];
            runner->structInstances[i] = moved;
            moved->structRegistryIndex = i;
        }
        arrpop(runner->structInstances);

        s->structRegistryIndex = -1;
        s->refCount = 0; // drop the registry's ref; we are about to free
        Instance_free(s);
    }
}

void Runner_cleanupDestroyedInstances(Runner* runner) {
    int32_t count = (int32_t) arrlen(runner->instances);
    int32_t writeIdx = 0;
    repeat(count, i) {
        Instance* inst = runner->instances[i];
        if (!inst->destroyed) {
            runner->instances[writeIdx++] = inst;
        } else {
            Runner_removeInstanceFromObjectLists(runner, inst);
            hmdel(runner->instancesById, inst->instanceId);
            Instance_free(inst);
            // Cached drawables hold raw Instance* that we just freed; force a rebuild before the next draw.
            runner->drawableListStructureDirty = true;
        }
    }
    arrsetlen(runner->instances, writeIdx);
}

void Runner_initFirstRoom(Runner* runner) {
    DataWin* dataWin = runner->dataWin;
    require(dataWin->gen8.roomOrderCount > 0);

    int32_t firstRoomIndex = dataWin->gen8.roomOrder[0];

    // Run global initialization scripts.
    runner->vmContext->currentInstance = runner->globalScopeInstance;

    repeat(dataWin->glob.count, i) {
        int32_t codeId = dataWin->glob.codeIds[i];

        if (codeId >= 0 && dataWin->code.count > (uint32_t)codeId) {
            fprintf(stderr, "Runner: Executing global init script: %s\n",
                    dataWin->code.entries[codeId].name);

            RValue result = VM_executeCode(runner->vmContext, codeId);
            RValue_free(&result);
        }
    }

    runner->vmContext->currentInstance = nullptr;

    fprintf(stderr, "[STARTUP] Before initRoom\n");
    fflush(stderr);

    initRoom(runner, firstRoomIndex);

    fprintf(stderr, "[STARTUP] After initRoom\n");
    fflush(stderr);

    fprintf(stderr, "[STARTUP] Before GAME_START\n");
    fflush(stderr);

    Runner_executeEventForAll(runner, EVENT_OTHER, OTHER_GAME_START);

    fprintf(stderr, "[STARTUP] After GAME_START\n");
    fflush(stderr);

    runner->gameStartFired = true;

    fprintf(stderr, "[STARTUP] Before ROOM_START\n");
    fflush(stderr);

    Runner_executeEventForAll(runner, EVENT_OTHER, OTHER_ROOM_START);

    fprintf(stderr, "[STARTUP] After ROOM_START\n");
    fflush(stderr);

    fprintf(stderr, "[STARTUP] Before SPRITE_PREFETCH\n");
    fflush(stderr);

    Runner_prefetchRuntimeSprites(runner);

    fprintf(stderr, "[STARTUP] After SPRITE_PREFETCH\n");
    fflush(stderr);
}


// ===[ Collision Event Dispatch ]===

static void executeCollisionEvent(Runner* runner, Instance* self, Instance* other, int32_t targetObjectIndex) {
    VMContext* vm = runner->vmContext;

    // Save event context
    int32_t savedEventType = vm->currentEventType;
    int32_t savedEventSubtype = vm->currentEventSubtype;
    int32_t savedEventObjectIndex = vm->currentEventObjectIndex;
    struct Instance* savedOtherInstance = vm->otherInstance;

    // Set collision event context
    vm->currentEventType = EVENT_COLLISION;
    vm->currentEventSubtype = targetObjectIndex;
    vm->otherInstance = other;

    int32_t ownerObjectIndex = -1;
    int32_t codeId = findEventCodeIdAndOwner(runner, self->objectIndex, EVENT_COLLISION, targetObjectIndex, &ownerObjectIndex);

    vm->currentEventObjectIndex = ownerObjectIndex;

#ifdef ENABLE_VM_TRACING
    if (codeId >= 0 && shlen(vm->eventsToBeTraced) != -1) {
        const char* selfName = runner->dataWin->objt.objects[self->objectIndex].name;
        const char* targetName = runner->dataWin->objt.objects[targetObjectIndex].name;
        bool shouldTrace = shgeti(vm->eventsToBeTraced, "*") != -1 || shgeti(vm->eventsToBeTraced, "Collision") != -1 || shgeti(vm->eventsToBeTraced, selfName) != -1;
        if (shouldTrace) {
            fprintf(stderr, "Runner: [%s] Collision with %s (instanceId=%d, otherId=%d)\n", selfName, targetName, self->instanceId, other->instanceId);
        }
    }
#endif

    executeCode(runner, self, codeId);

    // Restore event context
    vm->currentEventType = savedEventType;
    vm->currentEventSubtype = savedEventSubtype;
    vm->currentEventObjectIndex = savedEventObjectIndex;
    vm->otherInstance = savedOtherInstance;
}

// ===[ Path Adaptation ]===
// Advances path position and updates instance x/y (HTML5: yyInstance.js Adapt_Path, lines 2755-2881)
// Returns true if end of path was reached (and pathSpeed != 0), to fire OTHER_END_OF_PATH event.
static bool adaptPath(Runner* runner, Instance* inst) {
    if (0 > inst->pathIndex) return false;

    DataWin* dataWin = runner->dataWin;
    if ((uint32_t) inst->pathIndex >= dataWin->path.count) return false;

    GamePath* path = &dataWin->path.paths[inst->pathIndex];
    if (0.0 >= path->length) return false;

    bool atPathEnd = false;

    GMLReal orient = inst->pathOrientation * M_PI / 180.0;

    // Get current position's speed factor
    PathPositionResult cur = GamePath_getPosition(path, inst->pathPosition);
    GMLReal sp = cur.speed / (100.0 * inst->pathScale);

    // Advance position (compute in higher precision, truncate to float on store - matches native runner)
    inst->pathPosition = (float) (inst->pathPosition + inst->pathSpeed * sp / path->length);

    // Handle end actions if position out of [0,1]
    PathPositionResult pos0 = GamePath_getPosition(path, 0.0f);
    if (inst->pathPosition >= 1.0f || 0.0f >= inst->pathPosition) {
        atPathEnd = (inst->pathSpeed == 0.0f) ? false : true;

        switch (inst->pathEndAction) {
            // stop moving
            case 0: {
                if (inst->pathSpeed >= 0.0f) {
                    if (inst->pathSpeed != 0.0f) {
                        inst->pathPosition = 1.0f;
                        inst->pathIndex = -1;
                    }
                } else {
                    inst->pathPosition = 0.0f;
                    inst->pathIndex = -1;
                }
                break;
            }
            // continue from start position (restart)
            case 1: {
                if (0.0f > inst->pathPosition) {
                    inst->pathPosition += 1.0f;
                } else {
                    inst->pathPosition -= 1.0f;
                }
                break;
            }
            // continue from current position
            case 2: {
                PathPositionResult pos1 = GamePath_getPosition(path, 1.0f);
                GMLReal xx = pos1.x - pos0.x;
                GMLReal yy = pos1.y - pos0.y;
                GMLReal xdif = inst->pathScale * (xx * GMLReal_cos(orient) + yy * GMLReal_sin(orient));
                GMLReal ydif = inst->pathScale * (yy * GMLReal_cos(orient) - xx * GMLReal_sin(orient));

                if (0.0f > inst->pathPosition) {
                    inst->pathXStart -= (float) xdif;
                    inst->pathYStart -= (float) ydif;
                    inst->pathPosition += 1.0f;
                } else {
                    inst->pathXStart += (float) xdif;
                    inst->pathYStart += (float) ydif;
                    inst->pathPosition -= 1.0f;
                }
                break;
            }
            // reverse
            case 3: {
                if (0.0f > inst->pathPosition) {
                    inst->pathPosition = -inst->pathPosition;
                    inst->pathSpeed = (float) GMLReal_fabs(inst->pathSpeed);
                } else {
                    inst->pathPosition = 2.0f - inst->pathPosition;
                    inst->pathSpeed = (float) -GMLReal_fabs(inst->pathSpeed);
                }
                break;
            }
            // default: stop
            default: {
                inst->pathPosition = 1.0f;
                inst->pathIndex = -1;
                break;
            }
        }
    }

    // Find the new position in the room
    PathPositionResult newPos = GamePath_getPosition(path, inst->pathPosition);
    GMLReal xx = newPos.x - pos0.x; // relative
    GMLReal yy = newPos.y - pos0.y;

    GMLReal newx = inst->pathXStart + inst->pathScale * (xx * GMLReal_cos(orient) + yy * GMLReal_sin(orient));
    GMLReal newy = inst->pathYStart + inst->pathScale * (yy * GMLReal_cos(orient) - xx * GMLReal_sin(orient));

    // Trick to set the direction: set hspeed/vspeed to delta, which updates direction
    inst->hspeed = (float) (newx - inst->x);
    inst->vspeed = (float) (newy - inst->y);
    Instance_computeSpeedFromComponents(inst);

    // Normal speed should not be used
    inst->speed = 0.0f;
    inst->hspeed = 0.0f;
    inst->vspeed = 0.0f;

    // Set the new position
    inst->x = (float) newx;
    inst->y = (float) newy;

    SpatialGrid_markInstanceAsDirty(runner->spatialGrid, inst);

    return atPathEnd;
}

static void dispatchCollisionEvents(Runner* runner) {
    DataWin* dataWin = runner->dataWin;
    // Iterate only the objects that have any collision event in their parent chain.
    int32_t* selfObjects = (runner->objectsWithAnyEventOfType != nullptr) ? runner->objectsWithAnyEventOfType[EVENT_COLLISION] : nullptr;
    if (selfObjects == nullptr) return;
    int32_t selfObjCount = (int32_t) arrlen(selfObjects);

    repeat(selfObjCount, soIdx) {
        int32_t selfObjIdx = selfObjects[soIdx];
        Instance** selfBucket = runner->instancesByExactObject[selfObjIdx];
        int32_t selfBucketCount = (int32_t) arrlen(selfBucket);
        if (selfBucketCount == 0) continue;

        // Snapshot the self bucket: collision handlers can spawn/destroy/instance_change. Iterating a snapshot also keeps newly-created instances from firing collisions in this same phase.
        int32_t selfSnapBase = (int32_t) arrlen(runner->instanceSnapshots);
        arrsetlen(runner->instanceSnapshots, selfSnapBase + selfBucketCount);
        memcpy(&runner->instanceSnapshots[selfSnapBase], selfBucket, (size_t) selfBucketCount * sizeof(Instance*));

        repeat(selfBucketCount, si) {
            Instance* self = runner->instanceSnapshots[selfSnapBase + si];
            if (!self->active) continue;

        InstanceBBox bboxSelf;
        Sprite* sprSelf;
        bool selfDirty = true;

        // Walk the parent chain to find all collision event handlers for this object
        int32_t currentObj = self->objectIndex;
        int depth = 0;
        while (currentObj >= 0 && dataWin->objt.count > (uint32_t) currentObj && 32 > depth) {
            GameObject* obj = &dataWin->objt.objects[currentObj];

            ObjectEventList* eventList = &obj->eventLists[EVENT_COLLISION];
            repeat(eventList->eventCount, evtIdx) {
                ObjectEvent* evt = &eventList->events[evtIdx];
                int32_t targetObjIndex = (int32_t) evt->eventSubtype;

                if (evt->actionCount == 0 || 0 > evt->actions[0].codeId) continue;

                // Iterate only the descendant-inclusive list for the target object via a snapshot, so nested user code (collision handlers calling instance_exists, with (...), etc.) can push/pop their own snapshots above ours without corrupting this iteration.
                int32_t snapBase = Runner_pushInstancesOfObject(runner, targetObjIndex);
                int32_t snapEnd  = (int32_t) arrlen(runner->instanceSnapshots);
                for (int32_t snapIdx = snapBase; snapEnd > snapIdx; snapIdx++) {
                    Instance* other = runner->instanceSnapshots[snapIdx];
                    if (!other->active) continue;
                    if (other == self) continue;

                    // Compute bboxes
                    if (selfDirty) {
                        bboxSelf = Collision_computeBBox(dataWin, self);
                        sprSelf = Collision_getSprite(dataWin, self);
                        selfDirty = false;
                    }
                    InstanceBBox bboxOther = Collision_computeBBox(dataWin, other);
                    if (!bboxSelf.valid || !bboxOther.valid) continue;

                    // AABB overlap test
                    if (bboxSelf.left >= bboxOther.right || bboxOther.left >= bboxSelf.right || bboxSelf.top >= bboxOther.bottom || bboxOther.top >= bboxSelf.bottom)
                        continue;

                    // Precise collision check if either sprite needs it (per-pixel for sepMasks==1, OBB SAT for rotated sepMasks==2).
                    Sprite* sprOther = Collision_getSprite(dataWin, other);
                    bool needsPrecise = (sprSelf != nullptr && sprSelf->sepMasks == 1) || (sprOther != nullptr && sprOther->sepMasks == 1) || Collision_obbNeedsSAT(sprSelf, self) || Collision_obbNeedsSAT(sprOther, other);

                    if (needsPrecise) {
                        if (!Collision_instancesOverlapPrecise(dataWin, runner->collisionCompatibilityMode, self, other, bboxSelf, bboxOther)) continue;
                    }

                    // Collision detected! If either instance is solid, restore both to xprevious/yprevious.
                    bool hadSolid = self->solid || other->solid;
                    if (hadSolid) {
                        self->x = self->xprevious;
                        self->y = self->yprevious;
                        if (self->pathIndex >= 0) self->pathPosition = self->pathPositionPrevious;
                        other->x = other->xprevious;
                        other->y = other->yprevious;
                        if (other->pathIndex >= 0) other->pathPosition = other->pathPositionPrevious;
                        SpatialGrid_markInstanceAsDirty(runner->spatialGrid, self);
                        SpatialGrid_markInstanceAsDirty(runner->spatialGrid, other);
                    }

                    // We don't need to call "SpatialGrid_markInstanceAsDirty" here because *technically* just because a collision happened, doesn't mean that the instances have moved
                    // And if it DOES move via GML, the variable write handlers will set it to dirty

                    executeCollisionEvent(runner, self, other, targetObjIndex);

                    // Native parity for solids: collision event can alter path state, so run one
                    // post-event path adaptation and apply its hspeed/vspeed step.
                    if (hadSolid && self->active && other->active) {
                        adaptPath(runner, self);
                        adaptPath(runner, other);
                        if (self->hspeed != 0.0f || self->vspeed != 0.0f) {
                            self->x += self->hspeed;
                            self->y += self->vspeed;
                            SpatialGrid_markInstanceAsDirty(runner->spatialGrid, self);
                        }
                        if (other->hspeed != 0.0f || other->vspeed != 0.0f) {
                            other->x += other->hspeed;
                            other->y += other->vspeed;
                            SpatialGrid_markInstanceAsDirty(runner->spatialGrid, other);
                        }
                    }

                    // The collision event may have moved our instance, so we'll need to regenerate our self attributes!
                    selfDirty = true;
                }
                Runner_popInstanceSnapshot(runner, snapBase);
            }

            currentObj = obj->parentId;
            depth++;
        }
        }

        arrsetlen(runner->instanceSnapshots, selfSnapBase);
    }
}

// ===[ View Following + Clamping ]===
// Single-axis follow with border-based scrolling, room clamping, and speed limit.
static int32_t followAxis(int32_t viewPos, int32_t viewSize, int32_t targetPos, uint32_t border, int32_t speed, int32_t roomSize) {
    int32_t pos = viewPos;

    // Border-based scrolling
    if (2 * (int32_t) border >= viewSize) {
        pos = targetPos - viewSize / 2;
    } else if (targetPos - (int32_t) border < viewPos) {
        pos = targetPos - (int32_t) border;
    } else if (targetPos + (int32_t) border > viewPos + viewSize) {
        pos = targetPos + (int32_t) border - viewSize;
    }

    // Clamp to room bounds
    if (0 > pos) pos = 0;
    if (pos + viewSize > roomSize) pos = roomSize - viewSize;

    // Speed limit
    if (speed >= 0) {
        if (pos < viewPos && viewPos - pos > speed) pos = viewPos - speed;
        if (pos > viewPos && pos - viewPos > speed) pos = viewPos + speed;
    }

    return pos;
}

static void updateViews(Runner* runner) {
    Room* room = runner->currentRoom;
    if (!runner->viewsEnabled) return;

    repeat(MAX_VIEWS, vi) {
        RuntimeView* view = &runner->views[vi];
        if (!view->enabled) continue;
        GMLCamera* camera = Runner_getCameraForView(runner, (int32_t) vi);
        if (camera == nullptr || 0 > camera->objectId) continue;

        // Find first active instance of the target object.
        Instance* target = nullptr;
        if (camera->objectId >= 0 && runner->dataWin->objt.count > (uint32_t) camera->objectId) {
            Instance** bucket = runner->instancesByObject[camera->objectId];
            int32_t bucketCount = (int32_t) arrlen(bucket);
            repeat(bucketCount, i) {
                if (bucket[i]->active) { target = bucket[i]; break; }
            }
        }

        if (target != nullptr) {
            int32_t ix = (int32_t) GMLReal_floor(target->x);
            int32_t iy = (int32_t) GMLReal_floor(target->y);
            camera->viewX = followAxis(camera->viewX, camera->viewWidth, ix, camera->borderX, camera->speedX, (int32_t) room->width);
            camera->viewY = followAxis(camera->viewY, camera->viewHeight, iy, camera->borderY, camera->speedY, (int32_t) room->height);
            view->viewX = camera->viewX;
            view->viewY = camera->viewY;
        }
    }
}

static void dispatchOutsideRoomEvents(Runner* runner) {
    DataWin* dataWin = runner->dataWin;
    int32_t outsideSlot = EventSlotMap_lookup(&runner->eventSlotMap, EVENT_OTHER, OTHER_OUTSIDE_ROOM);
    if (0 > outsideSlot) return;
    ResolvedEventTable* table = &runner->eventTable;
    uint32_t entryCount;
    SlotResponderEntry* entries = ResolvedEventTable_slotEntries(table, outsideSlot, &entryCount);
    if (entryCount == 0) return;

    int32_t roomWidth = (int32_t) runner->currentRoom->width;
    int32_t roomHeight = (int32_t) runner->currentRoom->height;

    repeat(entryCount, s) {
        int32_t objIdx = entries[s].concreteObjectId;
        Instance** bucket = runner->instancesByExactObject[objIdx];
        int32_t bucketCount = (int32_t) arrlen(bucket);
        if (bucketCount == 0) continue;

        // All instances in the bucket share the same exact objectIndex, so the handler resolves to one (codeId, owner).
        int32_t ownerObjectIndex = -1;
        int32_t codeId = ResolvedEventTable_lookup(table, objIdx, outsideSlot, &ownerObjectIndex);
        if (0 > codeId) continue;

        // Snapshot the bucket: an Outside Room handler can spawn/destroy/instance_change.
        int32_t snapshotBase = (int32_t) arrlen(runner->instanceSnapshots);
        arrsetlen(runner->instanceSnapshots, snapshotBase + bucketCount);
        memcpy(&runner->instanceSnapshots[snapshotBase], bucket, (size_t) bucketCount * sizeof(Instance*));

        repeat(bucketCount, i) {
            Instance* inst = runner->instanceSnapshots[snapshotBase + i];
            if (!inst->active) continue;

            bool outside;
            InstanceBBox bbox = Collision_computeBBox(dataWin, inst);
            if (bbox.valid) {
                outside = (0 > bbox.right || bbox.left > roomWidth || 0 > bbox.bottom || bbox.top > roomHeight);
            } else {
                outside = (0 > inst->x || inst->x > roomWidth || 0 > inst->y || inst->y > roomHeight);
            }

            if (outside && !inst->outsideRoom) {
                Runner_executeResolvedEvent(runner, inst, EVENT_OTHER, OTHER_OUTSIDE_ROOM, codeId, ownerObjectIndex);
                if (runner->pendingRoom >= 0) {
                    arrsetlen(runner->instanceSnapshots, snapshotBase);
                    return;
                }
            }

            inst->outsideRoom = outside;
        }

        arrsetlen(runner->instanceSnapshots, snapshotBase);
    }
}

static void persistRoomState(Runner* runner, int32_t roomIndex) {
    SavedRoomState* state = &runner->savedRoomStates[roomIndex];

    // Free any previously saved instances (from an earlier visit)
    int32_t prevSavedCount = (int32_t) arrlen(state->instances);
    repeat(prevSavedCount, i) {
        hmdel(runner->instancesById, state->instances[i]->instanceId);
        Instance_free(state->instances[i]);
    }
    arrfree(state->instances);
    state->instances = nullptr;
    hmfree(state->tileLayerMap);
    state->tileLayerMap = nullptr;
    freeRuntimeLayersArray(&state->runtimeLayers);

    // Separate persistent instances (travel with player) from room instances (saved)
    Instance** keptInstances = nullptr;
    int32_t count = (int32_t) arrlen(runner->instances);
    repeat(count, i) {
        Instance* inst = runner->instances[i];
        if (inst->persistent) {
            arrput(keptInstances, inst);
        } else if (inst->active) {
            arrput(state->instances, inst);
        } else {
            hmdel(runner->instancesById, inst->instanceId);
            Instance_free(inst);
        }
    }
    arrfree(runner->instances);
    runner->instances = keptInstances;

    // The per-object lists referenced the full pre-transition instance set (persistents, saved-to-state, and soon-to-be-freed). Only the kept persistents remain live, so rebuild from scratch from the final runner->instances.
    Runner_clearAllObjectLists(runner);
    repeat((int32_t) arrlen(runner->instances), i) {
        Runner_addInstanceToObjectLists(runner, runner->instances[i]);
    }

    // Save room visual state
    memcpy(state->backgrounds, runner->backgrounds, sizeof(runner->backgrounds));
    memcpy(state->views, runner->views, sizeof(runner->views));
    state->viewsEnabled = runner->viewsEnabled;
    memcpy(state->defaultCameras, runner->defaultCameras, sizeof(state->defaultCameras));
    state->backgroundColor = runner->backgroundColor;
    state->drawBackgroundColor = runner->drawBackgroundColor;

    // Transfer tile layer map ownership to saved state
    state->tileLayerMap = runner->tileLayerMap;
    runner->tileLayerMap = nullptr;

    // Transfer runtime layer ownership to saved state
    state->runtimeLayers = runner->runtimeLayers;
    runner->runtimeLayers = nullptr;

    state->initialized = true;
}


// Test the current mouse position against an instance's collision mask.
static bool Runner_mouseHitsInstance(Runner* runner, Instance* inst) {
    if (runner == nullptr || runner->mouse == nullptr ||
        !runner->mouse->positionValid || inst == nullptr || !inst->active) {
        return false;
    }

    GMLReal mx = (GMLReal) runner->mouse->x;
    GMLReal my = (GMLReal) runner->mouse->y;

    if (!Collision_pointInsideInstanceBox(runner->dataWin, inst, mx, my))
        return false;

    Sprite* spr = Collision_getSprite(runner->dataWin, inst);
    if (spr != nullptr && Collision_hasFrameMasks(spr) &&
        !Collision_pointInInstance(spr, inst, mx, my)) {
        return false;
    }

    return true;
}

// Dispatch the instance mouse events used by Matchmakers:
// Left Released (7), Mouse Enter (10), and Mouse Leave (11).
static void Runner_dispatchMouseEvents(Runner* runner) {
    if (runner == nullptr || runner->mouse == nullptr ||
        !runner->mouse->positionValid) {
        return;
    }

    int32_t count = (int32_t) arrlen(runner->instances);
    if (count == 0)
        return;

    // Snapshot because mouse-event code can create or destroy instances.
    int32_t snapshotBase = (int32_t) arrlen(runner->instanceSnapshots);
    arrsetlen(runner->instanceSnapshots, snapshotBase + count);
    memcpy(&runner->instanceSnapshots[snapshotBase],
           runner->instances,
           (size_t) count * sizeof(Instance*));

    for (int32_t i = 0; i < count; ++i) {
        Instance* inst = runner->instanceSnapshots[snapshotBase + i];

        if (inst == nullptr || !inst->active)
            continue;

        if (inst->objectIndex < 0 ||
            (uint32_t) inst->objectIndex >= runner->dataWin->objt.count) {
            continue;
        }

        int32_t enterOwner = -1;
        int32_t leaveOwner = -1;

        int32_t enterCode = findEventCodeIdAndOwner(
            runner, inst->objectIndex, EVENT_MOUSE,
            MOUSE_EVENT_ENTER, &enterOwner);

        int32_t leaveCode = findEventCodeIdAndOwner(
            runner, inst->objectIndex, EVENT_MOUSE,
            MOUSE_EVENT_LEAVE, &leaveOwner);

        int32_t releaseOwner = -1;
        int32_t releaseCode = findEventCodeIdAndOwner(
            runner, inst->objectIndex, EVENT_MOUSE,
            MOUSE_EVENT_LEFT_RELEASED, &releaseOwner);

        if (enterCode < 0 && leaveCode < 0 && releaseCode < 0)
            continue;

        bool wasOver = inst->mouseOver;
        bool isOver = Runner_mouseHitsInstance(runner, inst);

        // Update before user code so nested execution sees current state.
        inst->mouseOver = isOver;

        if (isOver && !wasOver && enterCode >= 0) {
            Runner_executeResolvedEvent(
                runner, inst, EVENT_MOUSE, MOUSE_EVENT_ENTER,
                enterCode, enterOwner);
        } else if (!isOver && wasOver && leaveCode >= 0) {
            Runner_executeResolvedEvent(
                runner, inst, EVENT_MOUSE, MOUSE_EVENT_LEAVE,
                leaveCode, leaveOwner);
        }

        if (!inst->active)
            continue;

        // Re-resolve after hover code in case it changed the instance object.
        if (isOver && runner->mouse->buttonReleased[MB_LEFT]) {
            releaseOwner = -1;
            releaseCode = findEventCodeIdAndOwner(
                runner, inst->objectIndex, EVENT_MOUSE,
                MOUSE_EVENT_LEFT_RELEASED, &releaseOwner);

            if (releaseCode >= 0) {
                Runner_executeResolvedEvent(
                    runner, inst, EVENT_MOUSE, MOUSE_EVENT_LEFT_RELEASED,
                    releaseCode, releaseOwner);
            }
        }
    }

    arrsetlen(runner->instanceSnapshots, snapshotBase);
}

void Runner_step(Runner* runner) {
    // The snapshot arena is stack-like and every push must be matched with a pop within the same frame. Assert that invariant at the top of each step: a non-zero length here means some site below pushed without popping, and we want a loud failure with the offending length so we can find it instead of silently leaking until the next frame.
    requireMessageFormatted(arrlen(runner->instanceSnapshots) == 0, "instanceSnapshots arena was not fully popped at end of previous frame (length=%td)", arrlen(runner->instanceSnapshots));

    // Check for gamepad connect/disconnect and fire Async System event
    for (int i = 0; MAX_GAMEPADS > i; i++) {
        GamepadSlot* slot = &runner->gamepads->slots[i];
        if (slot->connected != slot->connectedPrev) {
            DsMapEntry* map = nullptr;
            arrput(runner->dsMapPool, map);
            int32_t mapId = arrlen(runner->dsMapPool) - 1;
            
            DsMapEntry** mapPtr = &runner->dsMapPool[mapId];
            shput(*mapPtr, safeStrdup("event_type"), RValue_makeOwnedString(safeStrdup(slot->connected ? "gamepad discovered" : "gamepad lost")));
            shput(*mapPtr, safeStrdup("pad_index"), RValue_makeReal((GMLReal) i));
            
            runner->asyncLoadMapId = mapId;
            Runner_executeEventForAll(runner, EVENT_OTHER, OTHER_ASYNC_SYSTEM);
            
            // Clean up ds_map
            mapPtr = &runner->dsMapPool[mapId];
            if (*mapPtr != nullptr) {
                repeat(shlen(*mapPtr), j) {
                    free((*mapPtr)[j].key);
                    RValue_free(&(*mapPtr)[j].value);
                }
                shfree(*mapPtr);
                *mapPtr = nullptr;
            }
            runner->asyncLoadMapId = -1;
        }
    }

    // Save xprevious/yprevious and path_positionprevious for all active instances
    int32_t prevCount = (int32_t) arrlen(runner->instances);
    repeat(prevCount, i) {
        Instance* inst = runner->instances[i];
        if (inst->active) {
            inst->xprevious = inst->x;
            inst->yprevious = inst->y;
            inst->pathPositionPrevious = inst->pathPosition;
        }
    }

    // Advance image_index by image_speed for all active instances
    int32_t animCount = (int32_t) arrlen(runner->instances);
    int32_t animEndSlot = EventSlotMap_lookup(&runner->eventSlotMap, EVENT_OTHER, OTHER_ANIMATION_END);
    repeat(animCount, i) {
        Instance* inst = runner->instances[i];
        if (!inst->active) continue;
        if (0 > inst->spriteIndex) continue;

        inst->imageIndex += inst->imageSpeed;

        // Wrap image_index (matches HTML5 runner: manual subtract/add instead of using fmod)
        Sprite* sprite = &runner->dataWin->sprt.sprites[inst->spriteIndex];
        float frameCount = (float) sprite->textureCount;
        bool wrapped = false;
        if (inst->imageIndex >= frameCount) {
            inst->imageIndex -= frameCount;
            wrapped = true;
        } else if (0.0f > inst->imageIndex) {
            inst->imageIndex += frameCount;
            wrapped = true;
        }
        if (wrapped && animEndSlot >= 0) {
            int32_t ownerObjectIndex = -1;
            int32_t codeId = ResolvedEventTable_lookup(&runner->eventTable, inst->objectIndex, animEndSlot, &ownerObjectIndex);
            if (codeId >= 0) Runner_executeResolvedEvent(runner, inst, EVENT_OTHER, OTHER_ANIMATION_END, codeId, ownerObjectIndex);
        }
    }

    // Scroll backgrounds
    Runner_scrollBackgrounds(runner);

    // Advance GMS2 layer parallax (hspeed/vspeed per frame)
    size_t layerCount = arrlenu(runner->runtimeLayers);
    repeat(layerCount, i) {
        RuntimeLayer* rl = &runner->runtimeLayers[i];
        rl->xOffset += rl->hSpeed;
        rl->yOffset += rl->vSpeed;
        size_t elementCount = arrlenu(rl->elements);
        repeat(elementCount, j) {
            RuntimeLayerElement* el = &rl->elements[j];
            if (el->type != RuntimeLayerElementType_Background || el->backgroundElement == nullptr) continue;
            RuntimeBackgroundElement* bg = el->backgroundElement;
            if (bg->animationSpeed == 0.0f) continue;
            bg->frameIndex += bg->animationSpeed;
            if (bg->spriteIndex < 0 || (uint32_t) bg->spriteIndex >= runner->dataWin->sprt.count) continue;
            Sprite* sprite = &runner->dataWin->sprt.sprites[bg->spriteIndex];
            float frameCount = (float) sprite->textureCount;
            if (frameCount <= 0.0f) continue;
            while (bg->frameIndex >= frameCount) bg->frameIndex -= frameCount;
            while (bg->frameIndex < 0.0f) bg->frameIndex += frameCount;
        }
    }

    // Execute Begin Step for all instances
    Runner_executeEventForAll(runner, EVENT_STEP, STEP_BEGIN);

    // Dispatch keyboard events
    RunnerKeyboardState* kb = runner->keyboard;
    for (int32_t key = 0; GML_KEY_COUNT > key; key++) {
        if (kb->keyPressed[key]) {
            Runner_executeEventForAll(runner, EVENT_KEYPRESS, key);
        }
    }
    for (int32_t key = 0; GML_KEY_COUNT > key; key++) {
        if (kb->keyDown[key]) {
            Runner_executeEventForAll(runner, EVENT_KEYBOARD, key);
        }
    }
    for (int32_t key = 0; GML_KEY_COUNT > key; key++) {
        if (kb->keyReleased[key]) {
            Runner_executeEventForAll(runner, EVENT_KEYRELEASE, key);
        }
    }

    // Dispatch instance mouse events.
    Runner_dispatchMouseEvents(runner);

    // Process alarms. Outer loop is over alarm slots (matching the native runner's HandleAlarm), and for each slot we walk only the objects in the event table's bySlot range and only those objects' exact instance buckets. Idle instances are further skipped via activeAlarmMask.
    repeat(GML_ALARM_COUNT, alarmIdx) {
        int32_t alarmSlot = EventSlotMap_lookup(&runner->eventSlotMap, EVENT_ALARM, alarmIdx);
        if (0 > alarmSlot) continue;
        ResolvedEventTable* table = &runner->eventTable;
        uint32_t entryCount;
        SlotResponderEntry* entries = ResolvedEventTable_slotEntries(table, alarmSlot, &entryCount);

        repeat(entryCount, s) {
            int32_t objIdx = entries[s].concreteObjectId;
            Instance** bucket = runner->instancesByExactObject[objIdx];
            int32_t bucketCount = (int32_t) arrlen(bucket);
            if (bucketCount == 0) continue;

            // All instances in the bucket share the same exact objectIndex, so the handler resolves to one (codeId, owner).
            int32_t ownerObjectIndex = -1;
            int32_t codeId = ResolvedEventTable_lookup(table, objIdx, alarmSlot, &ownerObjectIndex);
            if (0 > codeId) continue;

            // Snapshot the bucket before dispatch: alarm code can call instance_change/instance_destroy/instance_create which mutate the live bucket. Iterating the snapshot also ensures newly-created instances do not fire alarms in this same phase.
            int32_t snapshotBase = (int32_t) arrlen(runner->instanceSnapshots);
            arrsetlen(runner->instanceSnapshots, snapshotBase + bucketCount);
            memcpy(&runner->instanceSnapshots[snapshotBase], bucket, (size_t) bucketCount * sizeof(Instance*));

            repeat(bucketCount, i) {
                Instance* inst = runner->instanceSnapshots[snapshotBase + i];
                if (!inst->active) continue;
                uint16_t bit = (uint16_t) (1u << alarmIdx);
                if ((inst->activeAlarmMask & bit) == 0) continue;

#ifdef ENABLE_VM_TRACING
                GameObject* object = &runner->dataWin->objt.objects[inst->objectIndex];
                if (shgeti(runner->vmContext->alarmsToBeTraced, "*") != -1 || shgeti(runner->vmContext->alarmsToBeTraced, object->name) != -1) {
                    fprintf(stderr, "VM: [%s] Ticking down Alarm[%d] (instanceId=%d), current tick is %d\n", object->name, alarmIdx, inst->instanceId, inst->alarm[alarmIdx]);
                }
#endif

                inst->alarm[alarmIdx]--;
                if (inst->alarm[alarmIdx] == 0) {
                    inst->alarm[alarmIdx] = -1;
                    inst->activeAlarmMask &= (uint16_t) ~bit;

#ifdef ENABLE_VM_TRACING
                    if (shgeti(runner->vmContext->alarmsToBeTraced, "*") != -1 || shgeti(runner->vmContext->alarmsToBeTraced, object->name) != -1) {
                        fprintf(stderr, "VM: [%s] Firing Alarm[%d] (instanceId=%d)\n", object->name, alarmIdx, inst->instanceId);
                    }
#endif

                    Runner_executeResolvedEvent(runner, inst, EVENT_ALARM, alarmIdx, codeId, ownerObjectIndex);
                }
            }

            arrsetlen(runner->instanceSnapshots, snapshotBase);
        }
    }

    // Execute Normal Step for all instances
    Runner_executeEventForAll(runner, EVENT_STEP, STEP_NORMAL);

    // Apply motion: friction, gravity, then x += hspeed, y += vspeed
    int32_t motionCount = (int32_t) arrlen(runner->instances);
    int32_t endOfPathSlot = EventSlotMap_lookup(&runner->eventSlotMap, EVENT_OTHER, OTHER_END_OF_PATH);
    repeat(motionCount, mi) {
        Instance* inst = runner->instances[mi];
        if (!inst->active) continue;

        // Friction: reduce speed toward zero (HTML5: AdaptSpeed)
        if (inst->friction != 0.0f) {
            float ns = (inst->speed > 0.0f) ? inst->speed - inst->friction : inst->speed + inst->friction;
            if ((inst->speed > 0.0f && ns < 0.0f) || (inst->speed < 0.0f && ns > 0.0f)) {
                inst->speed = 0.0f;
            } else if (inst->speed != 0.0f) {
                inst->speed = ns;
            }
            Instance_computeComponentsFromSpeed(inst);
        }

        // Gravity: add velocity in gravity_direction (HTML5: AddTo_Speed)
        if (inst->gravity != 0.0f) {
            GMLReal gravDirRad = inst->gravityDirection * (M_PI / 180.0);
            inst->hspeed += (float) (inst->gravity * clampFloat(GMLReal_cos(gravDirRad)));
            inst->vspeed -= (float) (inst->gravity * clampFloat(GMLReal_sin(gravDirRad)));
            Instance_computeSpeedFromComponents(inst);
        }

        // Path adaptation (HTML5: Adapt_Path, runs after friction/gravity, before x+=hspeed)
        if (adaptPath(runner, inst) && endOfPathSlot >= 0) {
            int32_t ownerObjectIndex = -1;
            int32_t codeId = ResolvedEventTable_lookup(&runner->eventTable, inst->objectIndex, endOfPathSlot, &ownerObjectIndex);
            if (codeId >= 0) Runner_executeResolvedEvent(runner, inst, EVENT_OTHER, OTHER_END_OF_PATH, codeId, ownerObjectIndex);
        }

        // Apply movement
        if (inst->hspeed != 0.0f || inst->vspeed != 0.0f) {
            inst->x += inst->hspeed;
            inst->y += inst->vspeed;
            SpatialGrid_markInstanceAsDirty(runner->spatialGrid, inst);
        }
    }

    // Dispatch outside room events
    dispatchOutsideRoomEvents(runner);

    // Dispatch collision events
    dispatchCollisionEvents(runner);

    // Execute End Step for all instances
    Runner_executeEventForAll(runner, EVENT_STEP, STEP_END);

    // Do not run broad Deltarune sprite prefetch periodically during gameplay.
    // It scans live instances and can synchronously load atlas pages; at 30 FPS
    // the old once-per-30-frames path produced a visible once-per-second hitch
    // in heavier Chapter 2 rooms. Room-start and instance-create prefetches
    // remain active, so newly entered rooms still warm their expected sprites.

    // Update view following
    updateViews(runner);

    // Handle game restart
    if (runner->pendingRoom == ROOM_RESTARTGAME) {
        // See you soon!
        // Free the currently-loaded non-eager room before reset so lazyLoadRooms stays steady-state.
        if (runner->dataWin->lazyLoadRooms && runner->currentRoom != nullptr && !runner->currentRoom->eagerlyLoaded) {
            DataWin_freeRoomPayload(runner->currentRoom);
        }
        Runner_reset(runner);
        Runner_initFirstRoom(runner);
        runner->frameCount++;
        return;
    }

    // Handle room transition
    if (runner->pendingRoom >= 0) {
        int32_t oldRoomIndex = runner->currentRoomIndex;
        Room* oldRoom = runner->currentRoom;
        const char* oldRoomName = oldRoom->name;

        // Fire Room End for all instances
        Runner_executeEventForAll(runner, EVENT_OTHER, OTHER_ROOM_END);

        int32_t newRoomIndex = runner->pendingRoom;
        runner->pendingRoom = -1;
        require(runner->dataWin->room.count > (uint32_t) newRoomIndex);
        const char* newRoomName = runner->dataWin->room.rooms[newRoomIndex].name;

        fprintf(stderr, "Room changed: %s (room %d) -> %s (room %d)\n", oldRoomName, oldRoomIndex, newRoomName, newRoomIndex);

        // If the old room is persistent, save its instance and visual state
        if (oldRoom->persistent) {
            persistRoomState(runner, oldRoomIndex);
        }

        // Free the outgoing room's payload under lazyLoadRooms, unless it's eagerly pinned or we're restarting the same room (initRoom would just re-load it).
        if (runner->dataWin->lazyLoadRooms && !oldRoom->eagerlyLoaded && newRoomIndex != oldRoomIndex) {
            DataWin_freeRoomPayload(oldRoom);
        }

        // Load new room
        initRoom(runner, newRoomIndex);

        // Fire Room Start for all instances
        Runner_executeEventForAll(runner, EVENT_OTHER, OTHER_ROOM_START);
        Runner_prefetchRuntimeSprites(runner);
    }

    Runner_cleanupDestroyedInstances(runner);
    Runner_sweepDeadStructs(runner);

    runner->frameCount++;
}

// ===[ State Dump ]===

void Runner_dumpState(Runner* runner) {
    DataWin* dataWin = runner->dataWin;
    VMContext* vm = runner->vmContext;
    int32_t instanceCount = (int32_t) arrlen(runner->instances);

    printf("=== Frame %d State Dump ===\n", runner->frameCount);
    printf("Room: %s (index %d)\n", runner->currentRoom->name, runner->currentRoomIndex);
    printf("Instance count: %d\n", instanceCount);

    repeat(instanceCount, i) {
        Instance* inst = runner->instances[i];
        if (!inst->active) continue;

        GameObject* gameObject = nullptr;
        const char* objName = "<unknown>";
        if (inst->objectIndex >= 0 && dataWin->objt.count > (uint32_t) inst->objectIndex) {
            gameObject = &dataWin->objt.objects[inst->objectIndex];
            objName = gameObject->name;
        }

        const char* spriteName = "<none>";
        if (inst->spriteIndex >= 0 && dataWin->sprt.count > (uint32_t) inst->spriteIndex) {
            spriteName = dataWin->sprt.sprites[inst->spriteIndex].name;
        }

        const char* parentName = "<none>";
        if (gameObject != nullptr && gameObject->parentId >= 0 && dataWin->objt.count > (uint32_t) gameObject->parentId) {
            parentName = dataWin->objt.objects[gameObject->parentId].name;
        }

        printf("\n--- Instance #%d (%s, objectIndex=%d) ---\n", inst->instanceId, objName, inst->objectIndex);
        printf("  Position: (%g, %g)\n", (double) inst->x, (double) inst->y);
        printf("  Depth: %d\n", inst->depth);
        printf("  Sprite: %s (index %d), imageIndex=%g, imageSpeed=%g\n", spriteName, inst->spriteIndex, (double) inst->imageIndex, (double) inst->imageSpeed);
        printf("  Scale: (%g, %g), Angle: %g, Alpha: %g, Blend: 0x%06X\n", (double) inst->imageXscale, (double) inst->imageYscale, (double) inst->imageAngle, (double) inst->imageAlpha, inst->imageBlend);
        printf("  Visible: %s, Active: %s, Solid: %s, Persistent: %s\n", inst->visible ? "true" : "false", inst->active ? "true" : "false", inst->solid ? "true" : "false", inst->persistent ? "true" : "false");
        printf("  Parent: %s (parentId=%d)\n", parentName, gameObject != nullptr ? gameObject->parentId : -1);

        // Active alarms
        bool hasAlarm = false;
        repeat(GML_ALARM_COUNT, alarmIdx) {
            if (inst->alarm[alarmIdx] >= 0) {
                if (!hasAlarm) { printf("  Alarms:"); hasAlarm = true; }
                printf(" [%d]=%d", alarmIdx, inst->alarm[alarmIdx]);
            }
        }
        if (hasAlarm) printf("\n");

        // Self variables
        bool hasSelfVars = false;
        bool hasSelfArrays = false;
        repeat(inst->selfVars.capacity, svIdx) {
            IntRValueEntry* entry = &inst->selfVars.entries[svIdx];
            if (entry->key == INT_RVALUE_HASHMAP_EMPTY_KEY) continue;
            int32_t varID = entry->key;
            RValue val = entry->value;
            if (val.type == RVALUE_UNDEFINED) continue;

            const char* varName = "?";
            repeat(dataWin->vari.variableCount, varIdx) {
                Variable* var = &dataWin->vari.variables[varIdx];
                if (var->instanceType == INSTANCE_SELF && var->varID == varID) {
                    varName = var->name;
                    break;
                }
            }

            if (val.type == RVALUE_ARRAY && val.array != nullptr) {
                if (!hasSelfArrays) { printf("  Self Arrays:\n"); hasSelfArrays = true; }
                repeat(GMLArray_length1D(val.array), ai) {
                    RValue* cell = GMLArray_slot(val.array, ai);
                    if (cell == nullptr || cell->type == RVALUE_UNDEFINED) continue;
                    char* innerStr = RValue_toStringFancy(*cell);
                    printf("    %s[%d] = %s\n", varName, (int) ai, innerStr);
                    free(innerStr);
                }
            } else {
                if (!hasSelfVars) { printf("  Self Variables:\n"); hasSelfVars = true; }
                char* valStr = RValue_toStringFancy(val);
                printf("    %s = %s\n", varName, valStr);
                free(valStr);
            }
        }
    }

    // Global variables (non-array)
    printf("\n=== Global Variables ===\n");
    repeat(dataWin->vari.variableCount, varIdx) {
        Variable* var = &dataWin->vari.variables[varIdx];
        if (var->instanceType != INSTANCE_GLOBAL || var->varID < 0) continue;
        if ((uint32_t) var->varID >= vm->globalVarCount) continue;
        RValue val = vm->globalVars[var->varID];
        if (val.type == RVALUE_UNDEFINED) continue;

        char* valStr = RValue_toStringFancy(val);
        printf("  %s = %s\n", var->name, valStr);
        free(valStr);
    }

    // Global arrays: scan globalVars slots for RVALUE_ARRAY entries
    repeat(dataWin->vari.variableCount, varIdx) {
        Variable* var = &dataWin->vari.variables[varIdx];
        if (var->instanceType != INSTANCE_GLOBAL || var->varID < 0) continue;
        if ((uint32_t) var->varID >= vm->globalVarCount) continue;
        RValue val = vm->globalVars[var->varID];
        if (val.type != RVALUE_ARRAY || val.array == nullptr) continue;
        repeat(GMLArray_length1D(val.array), ai) {
            RValue* cell = GMLArray_slot(val.array, ai);
            if (cell == nullptr || cell->type == RVALUE_UNDEFINED) continue;
            char* innerStr = RValue_toStringFancy(*cell);
            printf("  %s[%d] = %s\n", var->name, (int) ai, innerStr);
            free(innerStr);
        }
    }

    printf("\n=== End Frame %d State Dump ===\n", runner->frameCount);
}

// ===[ JSON State Dump ]===

static void writeRValueJson(JsonWriter* w, RValue val) {
    switch (val.type) {
        case RVALUE_REAL:
            JsonWriter_double(w, val.real);
            break;
        case RVALUE_INT32:
            JsonWriter_int(w, val.int32);
            break;
#ifndef NO_RVALUE_INT64
        case RVALUE_INT64:
            JsonWriter_int(w, val.int64);
            break;
#endif
        case RVALUE_STRING:
            JsonWriter_string(w, val.string);
            break;
        case RVALUE_BOOL:
            JsonWriter_bool(w, val.int32 != 0);
            break;
        case RVALUE_UNDEFINED:
            JsonWriter_null(w);
            break;
        case RVALUE_ARRAY: {
            // Render arrays as a JSON array. Skips RVALUE_UNDEFINED entries (they read as 0/null anyway).
            JsonWriter_beginArray(w);
            if (val.array != nullptr) {
                repeat(GMLArray_length1D(val.array), ai) {
                    RValue* cell = GMLArray_slot(val.array, ai);
                    writeRValueJson(w, cell != nullptr ? *cell : (RValue){ .type = RVALUE_UNDEFINED });
                }
            }
            JsonWriter_endArray(w);
            break;
        }
#if IS_BC17_OR_HIGHER_ENABLED
        case RVALUE_METHOD: {
            char buf[64];
            snprintf(buf, sizeof(buf), "<method:%d>", val.method->codeIndex);
            JsonWriter_string(w, buf);
            break;
        }
#endif
        case RVALUE_STRUCT: {
            char buf[64];
            snprintf(buf, sizeof(buf), "<struct:%u>", val.structInst != nullptr ? val.structInst->instanceId : 0);
            JsonWriter_string(w, buf);
            break;
        }
    }
}

char* Runner_dumpStateJson(Runner* runner) {
    DataWin* dataWin = runner->dataWin;
    VMContext* vm = runner->vmContext;
    int32_t instanceCount = (int32_t) arrlen(runner->instances);

    JsonWriter w = JsonWriter_create();

    JsonWriter_beginObject(&w);

    JsonWriter_propertyInt(&w, "frame", runner->frameCount);

    // Room info
    JsonWriter_key(&w, "room");
    JsonWriter_beginObject(&w);
    JsonWriter_propertyString(&w, "name", runner->currentRoom->name);
    JsonWriter_propertyInt(&w, "index", runner->currentRoomIndex);
    JsonWriter_endObject(&w);

    // Instances
    JsonWriter_key(&w, "instances");
    JsonWriter_beginArray(&w);

    repeat(instanceCount, i) {
        Instance* inst = runner->instances[i];
        if (!inst->active) continue;

        const char* objName = (inst->objectIndex >= 0 && dataWin->objt.count > (uint32_t) inst->objectIndex) ? dataWin->objt.objects[inst->objectIndex].name : nullptr;

        const char* spriteName = nullptr;
        if (inst->spriteIndex >= 0 && dataWin->sprt.count > (uint32_t) inst->spriteIndex) {
            spriteName = dataWin->sprt.sprites[inst->spriteIndex].name;
        }

        JsonWriter_beginObject(&w);

        JsonWriter_propertyInt(&w, "instanceId", inst->instanceId);
        JsonWriter_propertyString(&w, "objectName", objName);
        JsonWriter_propertyInt(&w, "objectIndex", inst->objectIndex);

        // Parent object
        const char* parentName = nullptr;
        int32_t parentId = -1;
        if (inst->objectIndex >= 0 && dataWin->objt.count > (uint32_t) inst->objectIndex) {
            parentId = dataWin->objt.objects[inst->objectIndex].parentId;
            if (parentId >= 0 && dataWin->objt.count > (uint32_t) parentId) {
                parentName = dataWin->objt.objects[parentId].name;
            }
        }
        JsonWriter_propertyString(&w, "parentObjectName", parentName);
        JsonWriter_propertyInt(&w, "parentObjectIndex", parentId);

        JsonWriter_propertyDouble(&w, "x", inst->x);
        JsonWriter_propertyDouble(&w, "y", inst->y);
        JsonWriter_propertyInt(&w, "depth", inst->depth);

        // Sprite
        JsonWriter_key(&w, "sprite");
        JsonWriter_beginObject(&w);
        JsonWriter_propertyString(&w, "name", spriteName);
        JsonWriter_propertyInt(&w, "index", inst->spriteIndex);
        JsonWriter_propertyDouble(&w, "imageIndex", inst->imageIndex);
        JsonWriter_propertyDouble(&w, "imageSpeed", inst->imageSpeed);
        JsonWriter_endObject(&w);

        // Scale
        JsonWriter_key(&w, "scale");
        JsonWriter_beginObject(&w);
        JsonWriter_propertyDouble(&w, "x", inst->imageXscale);
        JsonWriter_propertyDouble(&w, "y", inst->imageYscale);
        JsonWriter_endObject(&w);

        JsonWriter_propertyDouble(&w, "angle", inst->imageAngle);
        JsonWriter_propertyDouble(&w, "alpha", inst->imageAlpha);
        JsonWriter_propertyInt(&w, "blend", inst->imageBlend);
        JsonWriter_propertyBool(&w, "visible", inst->visible);
        JsonWriter_propertyBool(&w, "active", inst->active);
        JsonWriter_propertyBool(&w, "solid", inst->solid);
        JsonWriter_propertyBool(&w, "persistent", inst->persistent);

        // Alarms
        JsonWriter_key(&w, "alarms");
        JsonWriter_beginObject(&w);
        repeat(GML_ALARM_COUNT, alarmIdx) {
            if (inst->alarm[alarmIdx] >= 0) {
                char alarmKey[4];
                snprintf(alarmKey, sizeof(alarmKey), "%d", alarmIdx);
                JsonWriter_propertyInt(&w, alarmKey, inst->alarm[alarmIdx]);
            }
        }
        JsonWriter_endObject(&w);

        // Self variables (non-array, sparse hashmap)
        JsonWriter_key(&w, "selfVariables");
        JsonWriter_beginObject(&w);
        repeat(inst->selfVars.capacity, svIdx) {
            IntRValueEntry* entry = &inst->selfVars.entries[svIdx];
            if (entry->key == INT_RVALUE_HASHMAP_EMPTY_KEY) continue;
            int32_t varID = entry->key;
            RValue val = entry->value;
            if (val.type == RVALUE_UNDEFINED) continue;

            // Resolve variable name from VARI chunk
            const char* varName = "?";
            repeat(dataWin->vari.variableCount, varIdx) {
                Variable* var = &dataWin->vari.variables[varIdx];
                if (var->instanceType == INSTANCE_SELF && var->varID == varID) {
                    varName = var->name;
                    break;
                }
            }

            JsonWriter_key(&w, varName);
            writeRValueJson(&w, val);
        }
        JsonWriter_endObject(&w);
        JsonWriter_endObject(&w);
    }

    JsonWriter_endArray(&w);

    // Tiles
    Room* dumpRoom = runner->currentRoom;
    JsonWriter_key(&w, "tiles");
    JsonWriter_beginArray(&w);
    repeat(dumpRoom->tileCount, tileIdx) {
        RoomTile* tile = &dumpRoom->tiles[tileIdx];
        const char* bgName = (tile->backgroundDefinition >= 0 && dataWin->bgnd.count > (uint32_t) tile->backgroundDefinition) ? dataWin->bgnd.backgrounds[tile->backgroundDefinition].name : nullptr;

        JsonWriter_beginObject(&w);
        JsonWriter_propertyInt(&w, "index", tileIdx);
        JsonWriter_propertyInt(&w, "x", tile->x);
        JsonWriter_propertyInt(&w, "y", tile->y);
        JsonWriter_propertyInt(&w, "backgroundIndex", tile->backgroundDefinition);
        if (bgName != nullptr) {
            JsonWriter_propertyString(&w, "backgroundName", bgName);
        } else {
            JsonWriter_propertyNull(&w, "backgroundName");
        }
        JsonWriter_propertyInt(&w, "sourceX", tile->sourceX);
        JsonWriter_propertyInt(&w, "sourceY", tile->sourceY);
        JsonWriter_propertyInt(&w, "width", tile->width);
        JsonWriter_propertyInt(&w, "height", tile->height);
        JsonWriter_propertyInt(&w, "depth", tile->tileDepth);
        JsonWriter_propertyInt(&w, "instanceID", tile->instanceID);
        JsonWriter_propertyDouble(&w, "scaleX", tile->scaleX);
        JsonWriter_propertyDouble(&w, "scaleY", tile->scaleY);
        JsonWriter_propertyInt(&w, "color", tile->color);

        ptrdiff_t layerIdx = hmgeti(runner->tileLayerMap, tile->tileDepth);
        bool visible = (layerIdx >= 0) ? runner->tileLayerMap[layerIdx].value.visible : true;
        JsonWriter_propertyBool(&w, "visible", visible);
        JsonWriter_endObject(&w);
    }
    JsonWriter_endArray(&w);

    // Global variables (non-array)
    JsonWriter_key(&w, "globalVariables");
    JsonWriter_beginObject(&w);
    repeat(dataWin->vari.variableCount, varIdx) {
        Variable* var = &dataWin->vari.variables[varIdx];
        if (var->instanceType != INSTANCE_GLOBAL || var->varID < 0) continue;
        if ((uint32_t) var->varID >= vm->globalVarCount) continue;
        RValue val = vm->globalVars[var->varID];
        if (val.type == RVALUE_UNDEFINED) continue;

        JsonWriter_key(&w, var->name);
        writeRValueJson(&w, val);
    }
    JsonWriter_endObject(&w);
    JsonWriter_endObject(&w);

    char* result = JsonWriter_copyOutput(&w);
    JsonWriter_free(&w);
    return result;
}

static const char* roomLayerTypeName(uint32_t type) {
    switch (type) {
        case RoomLayerType_Path: return "Path";
        case RoomLayerType_Background: return "Background";
        case RoomLayerType_Instances: return "Instances";
        case RoomLayerType_Assets: return "Assets";
        case RoomLayerType_Tiles: return "Tiles";
        case RoomLayerType_Effect: return "Effect";
        case RoomLayerType_Path2: return "Path2";
        default: return "Unknown";
    }
}

static const char* runtimeElementTypeName(RuntimeLayerElementType type) {
    switch (type) {
        case RuntimeLayerElementType_Background: return "Background";
        case RuntimeLayerElementType_Sprite: return "Sprite";
        case RuntimeLayerElementType_Tilemap: return "Tilemap";
        case RuntimeLayerElementType_Tile: return "Tile";
        default: return "Unknown";
    }
}

static const char* gameProfileName(GameProfile profile) {
    switch (profile) {
        case GAME_PROFILE_UNDERTALE: return "UNDERTALE";
        case GAME_PROFILE_DELTARUNE: return "DELTARUNE";
        case GAME_PROFILE_GENERIC:
        default: return "GENERIC";
    }
}

static uint32_t countNonEmptyTileCells(RoomLayerTilesData* tiles) {
    if (tiles == nullptr || tiles->tileData == nullptr) return 0;
    uint32_t nonEmpty = 0;
    uint32_t total = tiles->tilesX * tiles->tilesY;
    repeat(total, i) {
        if ((tiles->tileData[i] & GMS2_TILE_INDEX_MASK) != 0) nonEmpty++;
    }
    return nonEmpty;
}

void Runner_dumpDiagnostics(Runner* runner, FILE* out) {
    if (runner == nullptr || out == nullptr) return;
    DataWin* dw = runner->dataWin;
    Room* room = runner->currentRoom;

    fprintf(out, "Butterscotch runtime diagnostics\n");
    fprintf(out, "frame=%d\n", runner->frameCount);
    fprintf(out, "profile=%s\n", gameProfileName(runner->gameProfile));
    fprintf(out, "data_win=%s\n", dw != nullptr && dw->filePath != nullptr ? dw->filePath : "<unknown>");
    fprintf(out, "game_name=%s\n", dw != nullptr && dw->gen8.name != nullptr ? dw->gen8.name : "<unknown>");
    fprintf(out, "room=%s index=%d order=%d size=%ux%u payloadLoaded=%d eagerlyLoaded=%d\n",
            room != nullptr && room->name != nullptr ? room->name : "<none>",
            runner->currentRoomIndex,
            runner->currentRoomOrderPosition,
            room != nullptr ? room->width : 0,
            room != nullptr ? room->height : 0,
            room != nullptr ? room->payloadLoaded : 0,
            room != nullptr ? room->eagerlyLoaded : 0);
    fprintf(out, "viewsEnabled=%d drawBackgroundColor=%d backgroundColor=0x%06X gui=%dx%d pendingRoom=%d shouldExit=%d\n",
            runner->viewsEnabled,
            runner->drawBackgroundColor,
            runner->backgroundColor,
            runner->guiWidth,
            runner->guiHeight,
            runner->pendingRoom,
            runner->shouldExit);
    fprintf(out, "instances=%td runtimeLayers=%td cachedDrawables=%td structureDirty=%d sortDirty=%d\n",
            arrlen(runner->instances),
            arrlen(runner->runtimeLayers),
            arrlen(runner->cachedDrawables),
            runner->drawableListStructureDirty,
            runner->drawableListSortDirty);

    fprintf(out, "\n[views]\n");
    repeat(MAX_VIEWS, i) {
        RuntimeView* v = &runner->views[i];
        if (!v->enabled) continue;
        GMLCamera* cam = Runner_getCameraForView(runner, (int32_t)i);
        fprintf(out, "view[%d] port=(%d,%d %dx%d) view=(%d,%d %dx%d) cam=%d camView=(%d,%d %dx%d) angle=%.3f\n",
                (int)i,
                v->portX, v->portY, v->portWidth, v->portHeight,
                v->viewX, v->viewY, v->viewWidth, v->viewHeight,
                v->cameraId,
                cam != nullptr ? cam->viewX : -1,
                cam != nullptr ? cam->viewY : -1,
                cam != nullptr ? cam->viewWidth : -1,
                cam != nullptr ? cam->viewHeight : -1,
                cam != nullptr ? cam->viewAngle : 0.0f);
    }

    fprintf(out, "\n[room-layers]\n");
    if (room != nullptr) {
        repeat(room->layerCount, i) {
            RoomLayer* layer = &room->layers[i];
            RuntimeLayer* runtimeLayer = Runner_findRuntimeLayerById(runner, (int32_t)layer->id);
            fprintf(out, "layer[%u] id=%u name=%s type=%s(%u) depth=%d visible=%d off=(%.2f,%.2f) speed=(%.2f,%.2f) runtime=%s rtVisible=%d rtDepth=%d rtOff=(%.2f,%.2f) elements=%td\n",
                    (unsigned)i,
                    layer->id,
                    layer->name != nullptr ? layer->name : "<unnamed>",
                    roomLayerTypeName(layer->type),
                    layer->type,
                    layer->depth,
                    layer->visible,
                    layer->xOffset, layer->yOffset,
                    layer->hSpeed, layer->vSpeed,
                    runtimeLayer != nullptr ? "yes" : "no",
                    runtimeLayer != nullptr ? runtimeLayer->visible : 0,
                    runtimeLayer != nullptr ? runtimeLayer->depth : 0,
                    runtimeLayer != nullptr ? runtimeLayer->xOffset : 0.0f,
                    runtimeLayer != nullptr ? runtimeLayer->yOffset : 0.0f,
                    runtimeLayer != nullptr ? arrlen(runtimeLayer->elements) : 0);

            if (layer->type == RoomLayerType_Tiles && layer->tilesData != nullptr) {
                RoomLayerTilesData* tiles = layer->tilesData;
                const char* bgName = "<invalid>";
                if (tiles->backgroundIndex >= 0 && dw != nullptr && (uint32_t)tiles->backgroundIndex < dw->bgnd.count) {
                    bgName = dw->bgnd.backgrounds[tiles->backgroundIndex].name;
                }
                fprintf(out, "  tilemap bg=%d/%s grid=%ux%u nonEmpty=%u total=%u\n",
                        tiles->backgroundIndex,
                        bgName != nullptr ? bgName : "<unnamed>",
                        tiles->tilesX,
                        tiles->tilesY,
                        countNonEmptyTileCells(tiles),
                        tiles->tilesX * tiles->tilesY);
            } else if (layer->type == RoomLayerType_Background && layer->backgroundData != nullptr) {
                RoomLayerBackgroundData* bg = layer->backgroundData;
                const char* spriteName = "<none>";
                if (bg->spriteIndex >= 0 && dw != nullptr && (uint32_t)bg->spriteIndex < dw->sprt.count) {
                    spriteName = dw->sprt.sprites[bg->spriteIndex].name;
                }
                fprintf(out, "  background visible=%d sprite=%d/%s tiled=(%d,%d) stretch=%d color=0x%08X firstFrame=%.2f alphaFromColor=%.3f\n",
                        bg->visible,
                        bg->spriteIndex,
                        spriteName != nullptr ? spriteName : "<unnamed>",
                        bg->hTiled,
                        bg->vTiled,
                        bg->stretch,
                        bg->color,
                        bg->firstFrame,
                        (float)((bg->color >> 24) & 0xFF) / 255.0f);
            } else if (layer->type == RoomLayerType_Assets && layer->assetsData != nullptr) {
                fprintf(out, "  assets sprites=%u legacyTiles=%u\n",
                        layer->assetsData->spriteCount,
                        layer->assetsData->legacyTileCount);
            }
        }
    }

    fprintf(out, "\n[runtime-layers]\n");
    repeat(arrlen(runner->runtimeLayers), i) {
        RuntimeLayer* layer = &runner->runtimeLayers[i];
        fprintf(out, "runtimeLayer[%d] id=%u depth=%d visible=%d dynamic=%d name=%s off=(%.2f,%.2f) speed=(%.2f,%.2f) elements=%td\n",
                (int)i,
                layer->id,
                layer->depth,
                layer->visible,
                layer->dynamic,
                layer->dynamicName != nullptr ? layer->dynamicName : "<parsed>",
                layer->xOffset, layer->yOffset,
                layer->hSpeed, layer->vSpeed,
                arrlen(layer->elements));
        repeat(arrlen(layer->elements), j) {
            RuntimeLayerElement* el = &layer->elements[j];
            fprintf(out, "  element[%d] id=%u type=%s(%d) visible=%d alpha=%.3f\n",
                    (int)j,
                    el->id,
                    runtimeElementTypeName(el->type),
                    el->type,
                    el->visible,
                    el->alpha);
            if (el->type == RuntimeLayerElementType_Tilemap && el->tilemapElement != nullptr) {
                RoomLayerTilesData* tiles = el->tilemapElement;
                fprintf(out, "    tilemapLayerId=%u bg=%d grid=%ux%u nonEmpty=%u\n",
                        el->tilemapLayerId,
                        tiles->backgroundIndex,
                        tiles->tilesX,
                        tiles->tilesY,
                        countNonEmptyTileCells(tiles));
            } else if (el->type == RuntimeLayerElementType_Background && el->backgroundElement != nullptr) {
                RuntimeBackgroundElement* bg = el->backgroundElement;
                const char* spriteName = "<none>";
                if (bg->spriteIndex >= 0 && dw != nullptr && (uint32_t)bg->spriteIndex < dw->sprt.count) {
                    spriteName = dw->sprt.sprites[bg->spriteIndex].name;
                }
                fprintf(out, "    background sprite=%d/%s visible=%d tiled=(%d,%d) stretch=%d alpha=%.3f blend=0x%06X off=(%.2f,%.2f) scale=(%.2f,%.2f) frame=%.2f speed=%.2f\n",
                        bg->spriteIndex,
                        spriteName != nullptr ? spriteName : "<unnamed>",
                        bg->visible,
                        bg->htiled,
                        bg->vtiled,
                        bg->stretch,
                        bg->alpha,
                        bg->blend,
                        bg->xOffset, bg->yOffset,
                        bg->xScale, bg->yScale,
                        bg->frameIndex,
                        bg->animationSpeed);
            } else if (el->type == RuntimeLayerElementType_Sprite && el->spriteElement != nullptr) {
                RuntimeSpriteElement* spr = el->spriteElement;
                const char* spriteName = "<none>";
                if (spr->spriteIndex >= 0 && dw != nullptr && (uint32_t)spr->spriteIndex < dw->sprt.count) {
                    spriteName = dw->sprt.sprites[spr->spriteIndex].name;
                }
                fprintf(out, "    sprite=%d/%s pos=(%d,%d) scale=(%.2f,%.2f) rot=%.2f frame=%.2f speed=%.2f color=0x%08X\n",
                        spr->spriteIndex,
                        spriteName != nullptr ? spriteName : "<unnamed>",
                        spr->x, spr->y,
                        spr->scaleX, spr->scaleY,
                        spr->rotation,
                        spr->frameIndex,
                        spr->animationSpeed,
                        spr->color);
            } else if (el->type == RuntimeLayerElementType_Tile && el->tileElement != nullptr) {
                RoomTile* tile = el->tileElement;
                fprintf(out, "    tile bg=%d src=(%d,%d %ux%u) dst=(%d,%d) depth=%d color=0x%08X\n",
                        tile->backgroundDefinition,
                        tile->sourceX, tile->sourceY,
                        tile->width, tile->height,
                        tile->x, tile->y,
                        tile->tileDepth,
                        tile->color);
            }
        }
    }

    fprintf(out, "\n[drawables]\n");
    repeat(arrlen(runner->cachedDrawables), i) {
        Drawable* d = &runner->cachedDrawables[i];
        if (d->type == DRAWABLE_INSTANCE) {
            Instance* inst = d->instance;
            const char* objName = "<invalid>";
            const char* spriteName = "<none>";
            if (inst != nullptr && inst->objectIndex >= 0 && dw != nullptr && (uint32_t)inst->objectIndex < dw->objt.count) {
                objName = dw->objt.objects[inst->objectIndex].name;
            }
            if (inst != nullptr && inst->spriteIndex >= 0 && dw != nullptr && (uint32_t)inst->spriteIndex < dw->sprt.count) {
                spriteName = dw->sprt.sprites[inst->spriteIndex].name;
            }
            fprintf(out, "drawable[%d] INSTANCE depth=%d id=%u obj=%d/%s sprite=%d/%s pos=(%.2f,%.2f) visible=%d active=%d layer=%d alpha=%.3f\n",
                    (int)i,
                    d->depth,
                    inst != nullptr ? inst->instanceId : 0,
                    inst != nullptr ? inst->objectIndex : -1,
                    objName != nullptr ? objName : "<unnamed>",
                    inst != nullptr ? inst->spriteIndex : -1,
                    spriteName != nullptr ? spriteName : "<unnamed>",
                    inst != nullptr ? inst->x : 0.0f,
                    inst != nullptr ? inst->y : 0.0f,
                    inst != nullptr ? inst->visible : 0,
                    inst != nullptr ? inst->active : 0,
                    inst != nullptr ? inst->layer : -1,
                    inst != nullptr ? inst->imageAlpha : 0.0f);
        } else if (d->type == DRAWABLE_LAYER) {
            RuntimeLayer* layer = Runner_findRuntimeLayerById(runner, d->runtimeLayerId);
            fprintf(out, "drawable[%d] LAYER depth=%d runtimeLayerId=%d found=%d visible=%d elements=%td\n",
                    (int)i,
                    d->depth,
                    d->runtimeLayerId,
                    layer != nullptr,
                    layer != nullptr ? layer->visible : 0,
                    layer != nullptr ? arrlen(layer->elements) : 0);
        } else {
            fprintf(out, "drawable[%d] TILE depth=%d tileIndex=%d\n", (int)i, d->depth, d->tileIndex);
        }
    }

    fprintf(out, "\n[active-instances-summary]\n");
    repeat(arrlen(runner->instances), i) {
        Instance* inst = runner->instances[i];
        if (inst == nullptr || !inst->active) continue;
        const char* objName = "<invalid>";
        const char* spriteName = "<none>";
        if (inst->objectIndex >= 0 && dw != nullptr && (uint32_t)inst->objectIndex < dw->objt.count) {
            objName = dw->objt.objects[inst->objectIndex].name;
        }
        if (inst->spriteIndex >= 0 && dw != nullptr && (uint32_t)inst->spriteIndex < dw->sprt.count) {
            spriteName = dw->sprt.sprites[inst->spriteIndex].name;
        }
        fprintf(out, "inst id=%u obj=%d/%s sprite=%d/%s pos=(%.2f,%.2f) depth=%d layer=%d vis=%d alpha=%.3f image=(%.2f spd %.2f)\n",
                inst->instanceId,
                inst->objectIndex,
                objName != nullptr ? objName : "<unnamed>",
                inst->spriteIndex,
                spriteName != nullptr ? spriteName : "<unnamed>",
                inst->x, inst->y,
                inst->depth,
                inst->layer,
                inst->visible,
                inst->imageAlpha,
                inst->imageIndex,
                inst->imageSpeed);
    }

    fprintf(out, "\n[end]\n");
}

void Runner_free(Runner* runner) {
    if (runner == nullptr) return;

    cleanupState(runner);

    if (runner->instancesByObject != nullptr) {
        uint32_t objectCount = runner->dataWin->objt.count;
        repeat(objectCount, i) {
            arrfree(runner->instancesByObject[i]);
        }
        free(runner->instancesByObject);
        runner->instancesByObject = nullptr;
    }
    if (runner->instancesByExactObject != nullptr) {
        uint32_t objectCount = runner->dataWin->objt.count;
        repeat(objectCount, i) {
            arrfree(runner->instancesByExactObject[i]);
        }
        free(runner->instancesByExactObject);
        runner->instancesByExactObject = nullptr;
    }
    if (runner->objectsWithAnyEventOfType != nullptr) {
        repeat(OBJT_EVENT_TYPE_COUNT, t) {
            arrfree(runner->objectsWithAnyEventOfType[t]);
        }
        free(runner->objectsWithAnyEventOfType);
        runner->objectsWithAnyEventOfType = nullptr;
    }
    arrfree(runner->cachedDrawables);
    runner->cachedDrawables = nullptr;
    arrfree(runner->instanceSnapshots);
    runner->instanceSnapshots = nullptr;
    arrfree(runner->eventDispatchInstances);
    runner->eventDispatchInstances = nullptr;
    ResolvedEventTable_free(&runner->eventTable);
    EventSlotMap_destroy(&runner->eventSlotMap);
    shfree(runner->assetsByName);

    RunnerKeyboard_free(runner->keyboard);
    RunnerMouse_free(runner->mouse);
    RunnerGamepad_free(runner->gamepads);
    Instance_free(runner->globalScopeInstance);
    NativeScripts_reset();
    free(runner);
}
